"""Phase 1 baseline diagnostic evaluation on existing vendor & problem PDFs."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from pipeline.schemas import DocumentPrediction, PagePrediction
from pipeline.ocr.liteparse_runner import load_pipeline_config


def _evaluate_problems_md_cases(docs_by_name: Dict[str, DocumentPrediction]) -> Dict[str, Any]:
    """Run targeted regression checks for the failures documented in Problems.md."""
    xray_doc = docs_by_name.get("Page_111_to_114_X-Ray_Test_Report_for_Throat_Insert.pdf")
    if xray_doc is None:
        return {"found": False}

    # Check Problem A (signature/handwriting/dates) & Problem B (table + footers) across all 4 pages
    all_md = "\n".join(p.markdown for p in xray_doc.pages)
    all_items_text = [t.text for p in xray_doc.pages for t in p.text_items]
    joined_items = "\n".join(all_items_text)

    footer_blocks = [
        {"page": p.page_number, "text": b.text}
        for p in xray_doc.pages
        for b in p.blocks
        if b.kind == "page_footer"
    ]

    # Check E-02(086) .. E-18(086) codes on page 1 (Problems/2.png)
    p1_md = xray_doc.pages[0].markdown if xray_doc.pages else ""
    expected_codes = [f"E-{i:02d}(086)" for i in range(2, 19)]
    found_codes = [c for c in expected_codes if c in p1_md]
    missing_codes = [c for c in expected_codes if c not in p1_md]

    # Check phantom empty 5th column pattern <td></td> at end of rows on page 1
    tr_blocks = re.findall(r"<tr>(.*?)</tr>", p1_md, flags=re.DOTALL)
    rows_with_trailing_empty_td = sum(1 for tr in tr_blocks if re.search(r"<td>\s*</td>\s*$", tr.strip()))

    # Check Problem A targets (located across pages 1-4)
    prob_a_checks = {
        "exposed_by_rakesh": "Rakesh Shamkule" in joined_items or "Rakesh Shamkule" in all_md,
        "date_14_05_26": "14/05/26" in joined_items or "14/05/2026" in joined_items,
        "date_15_05_26_clean": bool(re.search(r"15/0?5/26", joined_items)),
        "pankaj_clean": bool(re.search(r"Pankaj", joined_items, flags=re.IGNORECASE)),
    }

    return {
        "found": True,
        "document": xray_doc.source_pdf,
        "problem_a_signature_checks": prob_a_checks,
        "problem_b_table_checks": {
            "expected_part_codes": len(expected_codes),
            "found_part_codes": len(found_codes),
            "missing_part_codes": missing_codes,
            "page1_tr_count": len(tr_blocks),
            "page1_rows_with_trailing_empty_td": rows_with_trailing_empty_td,
            "date_14_05_2026_rowspan_occurrences": len(re.findall(r"rowspan=\"\d+\">14/05/2026", p1_md)),
        },
        "footer_recovery": {
            "page_footer_blocks_detected": len(footer_blocks),
            "sample_footers": footer_blocks[:6],
        },
    }


def _score_page_priority(pg: PagePrediction) -> Dict[str, Any]:
    """Score intrinsic difficulty / annotation priority for a page."""
    confs = [t.confidence for t in pg.text_items if t.confidence is not None]
    mean_conf = float(np.mean(confs)) if confs else 1.0
    p10_conf = float(np.percentile(confs, 10)) if confs else 1.0
    low_conf_70 = sum(1 for c in confs if c < 0.70)
    low_conf_50 = sum(1 for c in confs if c < 0.50)

    table_blocks = [b for b in pg.blocks if b.kind in ("table", "merged_table", "grid_fallback")]
    total_cells = 0
    empty_cells = 0
    for tb in table_blocks:
        for row in tb.rows or []:
            for cell in row:
                total_cells += 1
                if not cell.text.strip():
                    empty_cells += 1
    empty_cell_ratio = (empty_cells / total_cells) if total_cells else 0.0

    footer_count = sum(1 for b in pg.blocks if b.kind == "page_footer")
    header_count = sum(1 for b in pg.blocks if b.kind == "page_header")

    # Priority heuristic: lower confidence + higher low-conf count + empty table cells + grid_fallback
    grid_fallbacks = sum(1 for b in pg.blocks if b.kind == "grid_fallback")
    priority_score = (
        (1.0 - mean_conf) * 50.0
        + low_conf_70 * 0.5
        + low_conf_50 * 1.5
        + empty_cell_ratio * 15.0
        + grid_fallbacks * 5.0
    )

    return {
        "page_id": pg.page_id,
        "document_id": pg.document_id,
        "source_pdf": pg.source_pdf,
        "page_number": pg.page_number,
        "text_items": len(pg.text_items),
        "char_count": len(pg.text),
        "mean_conf": round(mean_conf, 4),
        "p10_conf": round(p10_conf, 4),
        "low_conf_lt_0_70": low_conf_70,
        "low_conf_lt_0_50": low_conf_50,
        "table_block_count": len(table_blocks),
        "table_kinds": [b.kind for b in table_blocks],
        "empty_cell_ratio": round(empty_cell_ratio, 4),
        "header_blocks": header_count,
        "footer_blocks": footer_count,
        "priority_score": round(priority_score, 3),
    }


def run_baseline_evaluation(root_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Evaluate baseline structured predictions and compare with legacy markdown_output."""
    root = (root_dir or Path.cwd()).resolve()
    cfg = load_pipeline_config(root / "configs/pipeline.yaml")
    paths = cfg["paths"]

    pred_dir = (root / paths["predictions_dir"]).resolve()
    legacy_dir = (root / paths["legacy_markdown_dir"]).resolve()
    eval_dir = (root / paths["baseline_eval_dir"]).resolve()
    eval_dir.mkdir(parents=True, exist_ok=True)

    doc_files = sorted(p for p in pred_dir.glob("*.json"))
    if not doc_files:
        raise FileNotFoundError(f"No structured document JSONs found in {pred_dir}")

    docs = [DocumentPrediction.model_validate_json(f.read_text(encoding="utf-8")) for f in doc_files]
    docs_by_name = {d.source_pdf: d for d in docs}

    doc_summaries: List[Dict[str, Any]] = []
    all_page_stats: List[Dict[str, Any]] = []

    for doc in docs:
        page_stats = [_score_page_priority(pg) for pg in doc.pages]
        all_page_stats.extend(page_stats)

        confs = [t.confidence for pg in doc.pages for t in pg.text_items if t.confidence is not None]
        legacy_md_path = legacy_dir / f"{Path(doc.source_pdf).stem}.md"
        legacy_chars = len(legacy_md_path.read_text(encoding="utf-8")) if legacy_md_path.exists() else 0
        new_chars = sum(len(pg.markdown) for pg in doc.pages)

        doc_summaries.append(
            {
                "source_pdf": doc.source_pdf,
                "document_id": doc.document_id,
                "pages": doc.total_pages,
                "elapsed_ms": doc.elapsed_ms,
                "ms_per_page": round(doc.elapsed_ms / max(doc.total_pages, 1), 1),
                "total_text_items": sum(s["text_items"] for s in page_stats),
                "mean_ocr_conf": round(float(np.mean(confs)), 4) if confs else 1.0,
                "p10_ocr_conf": round(float(np.percentile(confs, 10)), 4) if confs else 1.0,
                "low_conf_lt_0_70": sum(s["low_conf_lt_0_70"] for s in page_stats),
                "low_conf_lt_0_50": sum(s["low_conf_lt_0_50"] for s in page_stats),
                "header_blocks_recovered": sum(s["header_blocks"] for s in page_stats),
                "footer_blocks_recovered": sum(s["footer_blocks"] for s in page_stats),
                "table_blocks": sum(s["table_block_count"] for s in page_stats),
                "legacy_md_chars": legacy_chars,
                "new_md_chars": new_chars,
                "md_char_delta": new_chars - legacy_chars,
            }
        )

    priority_queue = sorted(all_page_stats, key=lambda s: s["priority_score"], reverse=True)[:15]
    problems_check = _evaluate_problems_md_cases(docs_by_name)

    total_pages = sum(d["pages"] for d in doc_summaries)
    total_ms = sum(d["elapsed_ms"] for d in doc_summaries)
    report = {
        "model": "ocria-nano@1.0.0",
        "config": docs[0].config if docs else {},
        "corpus_summary": {
            "total_documents": len(doc_summaries),
            "total_pages": total_pages,
            "total_elapsed_ms": round(total_ms, 1),
            "overall_ms_per_page": round(total_ms / max(total_pages, 1), 1),
            "total_footer_blocks_recovered": sum(d["footer_blocks_recovered"] for d in doc_summaries),
            "total_header_blocks_recovered": sum(d["header_blocks_recovered"] for d in doc_summaries),
            "total_table_blocks": sum(d["table_blocks"] for d in doc_summaries),
            "total_low_conf_lt_0_70": sum(d["low_conf_lt_0_70"] for d in doc_summaries),
        },
        "documents": doc_summaries,
        "problems_md_regression": problems_check,
        "priority_annotation_queue_top15": priority_queue,
    }

    (eval_dir / "baseline_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Render concise Markdown report
    lines = [
        "# Phase 1 Baseline Evaluation Report (`OCRia-nano-1` + Fixed LiteParse Config)",
        "",
        f"- **Documents:** {report['corpus_summary']['total_documents']} | **Total Pages:** {total_pages}",
        f"- **Avg Latency:** {report['corpus_summary']['overall_ms_per_page']} ms/page",
        f"- **Headers Recovered:** {report['corpus_summary']['total_header_blocks_recovered']} | **Footers Recovered:** {report['corpus_summary']['total_footer_blocks_recovered']}",
        f"- **Table Blocks Detected:** {report['corpus_summary']['total_table_blocks']}",
        f"- **Low-Confidence Lines (<0.70):** {report['corpus_summary']['total_low_conf_lt_0_70']}",
        "",
        "## Per-Document Baseline Summary",
        "",
        "| Document | Pages | ms/page | Text Items | Mean Conf | Conf <0.70 | Footers | Tables | Legacy MD Chars | New MD Chars |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for d in doc_summaries:
        lines.append(
            f"| {d['source_pdf']} | {d['pages']} | {d['ms_per_page']} | {d['total_text_items']} | "
            f"{d['mean_ocr_conf']:.3f} | {d['low_conf_lt_0_70']} | {d['footer_blocks_recovered']} | "
            f"{d['table_blocks']} | {d['legacy_md_chars']} | {d['new_md_chars']} |"
        )

    lines.extend(["", "## `Problems.md` Diagnostic Checks (`Page_111_to_114_X-Ray_Test_Report_for_Throat_Insert.pdf`)"])
    if problems_check.get("found"):
        pa = problems_check["problem_a_signature_checks"]
        pb = problems_check["problem_b_table_checks"]
        fr = problems_check["footer_recovery"]
        lines.extend(
            [
                f"- **Problem A (Signatures/Dates):** `Exposed By Rakesh`={pa['exposed_by_rakesh']}, `14/05/26`={pa['date_14_05_26']}, `15/5/26`={pa['date_15_05_26_clean']}, `Pankaj`={pa['pankaj_clean']}",
                f"- **Problem B (Table):** Part codes `E-02..E-18` found={pb['found_part_codes']}/{pb['expected_part_codes']}, missing={pb['missing_part_codes']}, rows with phantom trailing `<td></td>`={pb['page1_rows_with_trailing_empty_td']}/{pb['page1_tr_count']}",
                f"- **Footer Recovery (`keep_headers_footers=True`):** {fr['page_footer_blocks_detected']} footer blocks detected (legacy had 0).",
            ]
        )

    lines.extend(
        [
            "",
            "## Top 15 Priority Pages for  Human Annotation",
            "",
            "| Rank | Page ID | Mean Conf | Conf <0.70 | Conf <0.50 | Tables | Empty Cell Ratio | Priority Score |",
            "|---:|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for i, p in enumerate(priority_queue, 1):
        lines.append(
            f"| {i} | `{p['page_id']}` | {p['mean_conf']:.3f} | {p['low_conf_lt_0_70']} | {p['low_conf_lt_0_50']} | "
            f"{p['table_block_count']} | {p['empty_cell_ratio']:.2f} | {p['priority_score']} |"
        )

    (eval_dir / "baseline_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report
