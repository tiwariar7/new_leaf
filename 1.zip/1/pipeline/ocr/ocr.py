"""Backwards-compatible Parser wrapper upgraded to the Phase 1 LiteParse configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from pipeline.ocr.liteparse_runner import LiteParseBaselineRunner, load_pipeline_config


class Parser:
    """Batch PDF parser preserving main.py's interface with fixed LiteParse settings."""

    def __init__(
        self,
        input_dir: Optional[str] = None,
        output_dir: Optional[str] = None,
        skip_existing: bool = True,
    ):
        self.root_dir = Path.cwd()
        self.input_dir = Path(input_dir).resolve() if input_dir else (self.root_dir / "Input Docx").resolve()
        self.output_dir = Path(output_dir).resolve() if output_dir else (self.root_dir / "markdown_output").resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.skip_existing = skip_existing

        cfg = load_pipeline_config(self.root_dir / "configs/pipeline.yaml")
        cfg["paths"]["input_dir"] = str(self.input_dir)
        self.runner = LiteParseBaselineRunner(root_dir=self.root_dir, config=cfg)

    def process_pdf(self, pdf_path: Path) -> Path:
        """Convert one PDF to structured JSON/PNGs and write Markdown to output_dir."""
        output_file = self.output_dir / f"{pdf_path.stem}.md"
        doc_pred = self.runner.process_pdf(pdf_path, skip_existing=self.skip_existing)

        if not (self.skip_existing and output_file.exists()):
            md_text = "\n\n---\n\n".join(p.markdown for p in doc_pred.pages)
            output_file.write_text(md_text, encoding="utf-8")
            print(f"Saved: {output_file}")
        else:
            print(f"Skipping existing markdown: {output_file.name}")
        return output_file

    def process_directory(self):
        """Batch process all PDFs in the input folder."""
        pdf_files = sorted(f for f in self.input_dir.glob("*.pdf") if f.is_file())
        if not pdf_files:
            print(f"No PDFs found in: {self.input_dir}")
            return

        successful = 0
        failed = 0
        for pdf_file in pdf_files:
            try:
                self.process_pdf(pdf_file)
                successful += 1
            except Exception as e:
                print(f"FAILED: {pdf_file.name} -> {e}")
                failed += 1

        print("\n========== SUMMARY ==========")
        print(f"Total PDFs : {len(pdf_files)}")
        print(f"Successful : {successful}")
        print(f"Failed     : {failed}")
        print(f"Markdown   : {self.output_dir}")
        print(f"Structured : {self.runner.predictions_dir}")
        print(f"Pages PNGs : {self.runner.pages_dir}")


if __name__ == "__main__":
    Parser().process_directory()
