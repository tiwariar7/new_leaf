"""Structured LiteParse (OCRia-nano-1) runner with fixed baseline configuration."""

from __future__ import annotations

import json
import time
from dataclasses import asdict
from importlib.metadata import version as pkg_version
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from liteparse import LiteParse, ParsedPage

from pipeline.schemas import (
    DocumentPrediction,
    NormalizedRect,
    PagePrediction,
    PageRenderMeta,
    SerializedLayoutBlock,
    SerializedLayoutCell,
    SerializedTextItem,
    SerializedWordBox,
)
from pipeline.pdf_renderer import save_aligned_page_png, sha256_file, slugify_doc_id


def load_pipeline_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
    path = config_path or Path("configs/pipeline.yaml")
    if path.exists():
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    return {
        "paths": {
            "input_dir": "Input Docx",
            "legacy_markdown_dir": "markdown_output",
            "pages_dir": "data/pages",
            "predictions_dir": "data/predictions/baseline_ocria_nano_v1",
            "label_studio_dir": "data/label_studio",
            "baseline_eval_dir": "experiments/baseline",
        },
        "liteparse": {
            "ocr_backend": "ocria-nano",
            "ocr_backend_version": "1.0.0",
            "output_format": "markdown",
            "dpi": 300,
            "keep_headers_footers": True,
            "extract_blocks": True,
            "emit_word_boxes": True,
            "include_complexity": True,
            "ocr_despeckle_scans": True,
            "preserve_very_small_text": True,
            "batch_size": 10,
        },
    }


def _rect_from_obj(rect: Any, pw: float, ph: float) -> Optional[NormalizedRect]:
    if rect is None:
        return None
    return NormalizedRect.from_points(rect.x, rect.y, rect.width, rect.height, pw, ph)


def _serialize_page(
    pg: ParsedPage,
    render_meta: PageRenderMeta,
    model: str,
    model_version: str,
    liteparse_ver: str,
) -> PagePrediction:
    pw, ph = float(pg.width), float(pg.height)
    text_items: List[SerializedTextItem] = []
    for idx, ti in enumerate(pg.text_items):
        words = [
            SerializedWordBox(
                text=w.text,
                bbox=NormalizedRect.from_points(w.x, w.y, w.width, w.height, pw, ph),
            )
            for w in (ti.words or [])
        ]
        text_items.append(
            SerializedTextItem(
                item_index=idx,
                text=ti.text,
                bbox=NormalizedRect.from_points(ti.x, ti.y, ti.width, ti.height, pw, ph),
                confidence=round(float(ti.confidence), 4) if ti.confidence is not None else None,
                rotation=round(float(ti.rotation), 3),
                words=words,
            )
        )

    blocks: List[SerializedLayoutBlock] = []
    for b_idx, blk in enumerate(pg.blocks or []):
        header = (
            [
                SerializedLayoutCell(
                    text=c.text,
                    bbox=_rect_from_obj(c.bbox, pw, ph),
                    text_item_indices=list(c.text_item_indices),
                )
                for c in blk.header
            ]
            if blk.header is not None
            else None
        )
        rows = (
            [
                [
                    SerializedLayoutCell(
                        text=c.text,
                        bbox=_rect_from_obj(c.bbox, pw, ph),
                        text_item_indices=list(c.text_item_indices),
                    )
                    for c in row
                ]
                for row in blk.rows
            ]
            if blk.rows is not None
            else None
        )
        blocks.append(
            SerializedLayoutBlock(
                block_index=b_idx,
                kind=blk.kind,
                text=blk.text,
                level=blk.level,
                lines=blk.lines,
                bbox=_rect_from_obj(blk.bbox, pw, ph),
                header=header,
                rows=rows,
                text_item_indices=list(blk.text_item_indices),
            )
        )

    complexity_dict = asdict(pg.complexity) if pg.complexity is not None else None
    return PagePrediction(
        document_id=render_meta.document_id,
        page_id=render_meta.page_id,
        source_pdf=render_meta.source_pdf,
        page_number=render_meta.page_number,
        width_pt=render_meta.width_pt,
        height_pt=render_meta.height_pt,
        width_px=render_meta.width_px,
        height_px=render_meta.height_px,
        image_rel_path=render_meta.image_rel_path,
        model=model,
        model_version=model_version,
        liteparse_version=liteparse_ver,
        text=pg.text,
        markdown=pg.markdown,
        complexity=complexity_dict,
        text_items=text_items,
        blocks=blocks,
    )


class LiteParseBaselineRunner:
    """Runs fixed LiteParse + OCRia-nano-1 config, saves PNGs and structured JSON/Markdown."""

    def __init__(self, root_dir: Optional[Path] = None, config: Optional[Dict[str, Any]] = None):
        self.root_dir = (root_dir or Path.cwd()).resolve()
        self.cfg = config or load_pipeline_config(self.root_dir / "configs/pipeline.yaml")
        paths = self.cfg["paths"]
        lp_cfg = self.cfg["liteparse"]

        self.input_dir = (self.root_dir / paths["input_dir"]).resolve()
        self.pages_dir = (self.root_dir / paths["pages_dir"]).resolve()
        self.predictions_dir = (self.root_dir / paths["predictions_dir"]).resolve()
        self.markdown_out_dir = self.predictions_dir / "markdown"

        self.pages_dir.mkdir(parents=True, exist_ok=True)
        self.predictions_dir.mkdir(parents=True, exist_ok=True)
        self.markdown_out_dir.mkdir(parents=True, exist_ok=True)

        self.dpi = int(lp_cfg.get("dpi", 300))
        self.batch_size = int(lp_cfg.get("batch_size", 10))
        self.model_name = str(lp_cfg.get("ocr_backend", "ocria-nano"))
        self.model_version = str(lp_cfg.get("ocr_backend_version", "1.0.0"))
        self.liteparse_version = pkg_version("liteparse")

        self.lp_kwargs: Dict[str, Any] = {
            "ocr_backend": self.model_name,
            "output_format": lp_cfg.get("output_format", "markdown"),
            "dpi": self.dpi,
            "keep_headers_footers": bool(lp_cfg.get("keep_headers_footers", True)),
            "extract_blocks": bool(lp_cfg.get("extract_blocks", True)),
            "emit_word_boxes": bool(lp_cfg.get("emit_word_boxes", True)),
            "include_complexity": bool(lp_cfg.get("include_complexity", True)),
            "ocr_despeckle_scans": bool(lp_cfg.get("ocr_despeckle_scans", True)),
            "preserve_very_small_text": bool(lp_cfg.get("preserve_very_small_text", True)),
            "extract_screenshots": True,
            "quiet": True,
        }
        self.parser = LiteParse(**self.lp_kwargs)

    def process_pdf(self, pdf_path: Path, skip_existing: bool = False) -> DocumentPrediction:
        doc_id = slugify_doc_id(pdf_path)
        doc_json_path = self.predictions_dir / f"{doc_id}.json"
        md_path = self.markdown_out_dir / f"{pdf_path.stem}.md"

        if skip_existing and doc_json_path.exists() and md_path.exists():
            return DocumentPrediction.model_validate_json(doc_json_path.read_text(encoding="utf-8"))

        t0 = time.perf_counter()
        serialized_pages: List[PagePrediction] = []
        render_metas: List[PageRenderMeta] = []
        md_chunks: List[str] = []
        total_pages = 0

        for batch in self.parser.parse_batches(str(pdf_path), batch_size=self.batch_size):
            total_pages = batch.total_pages
            res = batch.result
            shot_by_page = {s.page_num: s for s in res.screenshots}
            if res.text:
                md_chunks.append(res.text)

            for pg in res.pages:
                sc = shot_by_page.get(pg.page_num)
                if sc is None:
                    raise RuntimeError(f"Missing screenshot for {pdf_path.name} page {pg.page_num}")
                out_png = self.pages_dir / doc_id / f"p{pg.page_num:04d}.png"
                meta = save_aligned_page_png(
                    image_bytes=sc.image_bytes,
                    out_path=out_png,
                    document_id=doc_id,
                    source_pdf=pdf_path.name,
                    page_number=pg.page_num,
                    dpi=self.dpi,
                    page_width_pt=pg.width,
                    page_height_pt=pg.height,
                    text_items=pg.text_items,
                    pages_root=self.pages_dir,
                )
                render_metas.append(meta)
                serialized_pages.append(
                    _serialize_page(
                        pg=pg,
                        render_meta=meta,
                        model=self.model_name,
                        model_version=self.model_version,
                        liteparse_ver=self.liteparse_version,
                    )
                )

        elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 2)
        doc_pred = DocumentPrediction(
            document_id=doc_id,
            source_pdf=pdf_path.name,
            pdf_sha256=sha256_file(pdf_path),
            total_pages=total_pages or len(serialized_pages),
            model=self.model_name,
            model_version=self.model_version,
            liteparse_version=self.liteparse_version,
            config={k: v for k, v in self.lp_kwargs.items() if k != "extract_screenshots"},
            elapsed_ms=elapsed_ms,
            pages=serialized_pages,
        )

        doc_json_path.write_text(doc_pred.model_dump_json(indent=2), encoding="utf-8")
        full_md = "\n\n---\n\n".join(p.markdown for p in serialized_pages) if serialized_pages else "\n\n".join(md_chunks)
        md_path.write_text(full_md, encoding="utf-8")

        doc_manifest_path = self.pages_dir / doc_id / "manifest.json"
        doc_manifest_path.write_text(
            json.dumps([m.model_dump() for m in render_metas], indent=2),
            encoding="utf-8",
        )
        return doc_pred

    def run_directory(self, skip_existing: bool = False) -> List[DocumentPrediction]:
        pdfs = sorted(p for p in self.input_dir.glob("*.pdf") if p.is_file())
        docs: List[DocumentPrediction] = []
        all_pages_jsonl: List[str] = []
        all_render_jsonl: List[str] = []

        for pdf in pdfs:
            print(f"[baseline] Processing {pdf.name} ...")
            doc_pred = self.process_pdf(pdf, skip_existing=skip_existing)
            docs.append(doc_pred)
            for pg in doc_pred.pages:
                all_pages_jsonl.append(pg.model_dump_json())
            manifest_file = self.pages_dir / doc_pred.document_id / "manifest.json"
            if manifest_file.exists():
                for item in json.loads(manifest_file.read_text(encoding="utf-8")):
                    all_render_jsonl.append(json.dumps(item))
            print(f"  -> {doc_pred.total_pages} pages in {doc_pred.elapsed_ms:.0f} ms")

        (self.predictions_dir / "pages.jsonl").write_text("\n".join(all_pages_jsonl) + "\n", encoding="utf-8")
        (self.pages_dir.parent / "pages_manifest.jsonl").write_text(
            "\n".join(all_render_jsonl) + "\n", encoding="utf-8"
        )
        return docs
