"""Automate Label Studio project creation, local storage attachment, task import, and export via SDK."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from label_studio_sdk.client import LabelStudio

from pipeline.ocr.liteparse_runner import load_pipeline_config


def _get_or_create_project(
    ls: LabelStudio,
    title: str,
    label_config_xml: str,
    pages_dir: Path,
) -> int:
    existing = {p.title: p.id for p in ls.projects.list()}
    if title in existing:
        pid = int(existing[title])
    else:
        proj = ls.projects.create(title=title, label_config=label_config_xml)
        pid = int(proj.id)

    storages = ls.import_storage.local.list(project=pid)
    pages_str = str(pages_dir.resolve())
    if not any(os.path.normpath(s.path or "") == os.path.normpath(pages_str) for s in storages):
        ls.import_storage.local.create(
            project=pid,
            path=pages_str,
            title="Rendered Pages PNGs",
            use_blob_urls=False,
        )
    return pid


def setup_label_studio_projects(
    url: str,
    api_key: str,
    batch: str = "focus12",
    root_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Create LS-P1, LS-P2, LS-P3 projects, connect storage, and import tasks automatically."""
    root = (root_dir or Path.cwd()).resolve()
    cfg = load_pipeline_config(root / "configs/pipeline.yaml")
    ls_dir = (root / cfg["paths"]["label_studio_dir"]).resolve()
    pages_dir = (root / cfg["paths"]["pages_dir"]).resolve()
    xml_dir = (root / "configs/label_studio").resolve()

    batch_files = {
        "focus12": ("ls_p1_focus12.json", "ls_p2_smart12.json", "ls_p3_smart12.json"),
        "smart12": ("ls_p1_smart12.json", "ls_p2_smart12.json", "ls_p3_smart12.json"),
        "pilot15": ("ls_p1_pilot15.json", "ls_p2_pilot15.json", None),
        "all": ("ls_p1_tasks.json", "ls_p2_table_tasks.json", None),
    }
    p1_file, p2_file, p3_file = batch_files[batch]

    ls = LabelStudio(base_url=url, api_key=api_key)
    summary: Dict[str, Any] = {"url": url, "batch": batch, "projects": {}}

    specs: List[tuple[str, str, Optional[str]]] = [
        ("LS-P1: OCR Correction & Error Triage", "p1_ocr_correction.xml", p1_file),
        ("LS-P2: Complex Table Structure", "p2_table_structure.xml", p2_file),
    ]
    if p3_file:
        specs.append(("LS-P3: Pairwise Preference", "p3_pairwise_pref.xml", p3_file))

    for title, xml_name, task_filename in specs:
        xml_text = (xml_dir / xml_name).read_text(encoding="utf-8")
        pid = _get_or_create_project(ls, title, xml_text, pages_dir)
        imported_count = 0
        if task_filename and (ls_dir / task_filename).exists():
            tasks = json.loads((ls_dir / task_filename).read_text(encoding="utf-8"))
            if tasks:
                ls.projects.import_tasks(id=pid, request=tasks)
                imported_count = len(tasks)
        summary["projects"][title] = {
            "project_id": pid,
            "imported_tasks": imported_count,
            "project_url": f"{url.rstrip('/')}/projects/{pid}/data",
        }
    return summary


def export_label_studio_projects(
    url: str,
    api_key: str,
    out_dir: Path,
) -> Dict[str, Path]:
    """Download JSON exports for LS-P1, LS-P2, LS-P3 if they exist."""
    ls = LabelStudio(base_url=url, api_key=api_key)
    out_dir.mkdir(parents=True, exist_ok=True)
    by_title = {p.title: int(p.id) for p in ls.projects.list()}
    exported: Dict[str, Path] = {}

    mapping = {
        "p1": "LS-P1: OCR Correction & Error Triage",
        "p2": "LS-P2: Complex Table Structure",
        "p3": "LS-P3: Pairwise Preference",
    }
    for key, title in mapping.items():
        if title not in by_title:
            continue
        data = ls.projects.exports.as_json(project_id=by_title[title])
        dest = out_dir / f"{key}_raw_export.json"
        dest.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        exported[key] = dest
    return exported
