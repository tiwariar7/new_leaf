"""Unified entry point & Phase 1/2 CLI for baseline OCR, Label Studio prep, QC, and feedback compilation."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pipeline.auto_preannotate import run_auto_preannotate
from pipeline.baseline_audit import run_baseline_evaluation
from pipeline.feedback_compiler import compile_p1_export, compile_p2_export
from pipeline.iaa_qc import run_qc_checks
from pipeline.labelling import export_label_studio_tasks
from pipeline.ls_sync import export_label_studio_projects, setup_label_studio_projects
from pipeline.ocr.liteparse_runner import LiteParseBaselineRunner, load_pipeline_config
from pipeline.ocr.ocr import Parser


def main() -> None:
    parser = argparse.ArgumentParser(description="Vendor PDF OCR & Human-Feedback Pipeline CLI")
    parser.add_argument(
        "command",
        nargs="?",
        default=None,
        choices=[
            "run-baseline",
            "build-ls-tasks",
            "auto-preannotate",
            "eval-baseline",
            "all",
            "ls-setup",
            "ls-export",
            "check-qc",
            "compile-feedback",
        ],
        help="Pipeline stage to execute. If omitted, runs Parser on Input Docx.",
    )
    parser.add_argument("--skip-existing", action="store_true", help="Skip PDFs with existing baseline JSON.")
    parser.add_argument("--p1-export", type=Path, help="Path to exported Label Studio LS-P1 JSON.")
    parser.add_argument("--p2-export", type=Path, help="Path to exported Label Studio LS-P2 JSON.")
    parser.add_argument("--consensus-path", type=Path, help="Optional auto_consensus_p1.json path for focus12.")
    parser.add_argument("--version", default="v1", help="Dataset export version tag (for compile-feedback / ls-export).")
    parser.add_argument("--url", default="http://localhost:8080", help="Label Studio server URL.")
    parser.add_argument("--api-key", default=None, help="Label Studio User API token (Account & Settings).")
    parser.add_argument("--batch", default="focus12", choices=["focus12", "smart12", "pilot15", "all"])
    args = parser.parse_args()

    if args.command is None:
        batch_parser = Parser(
            input_dir=r"D:\Arman\1\Input Docx",
            skip_existing=True,
        )
        batch_parser.process_directory()
        return

    root = Path.cwd()
    cfg = load_pipeline_config(root / "configs/pipeline.yaml")
    paths = cfg["paths"]

    if args.command in ("run-baseline", "all"):
        runner = LiteParseBaselineRunner(root_dir=root)
        runner.run_directory(skip_existing=args.skip_existing)

    if args.command in ("build-ls-tasks", "all"):
        ls_summary = export_label_studio_tasks(root_dir=root)
        print("[label-studio] Exported:", json.dumps(ls_summary))

    if args.command == "auto-preannotate":
        auto_summary = run_auto_preannotate(root_dir=root)
        print("[auto-preannotate]", json.dumps(auto_summary, indent=2))

    if args.command in ("eval-baseline", "all"):
        report = run_baseline_evaluation(root_dir=root)
        print("[baseline-eval] Summary:", json.dumps(report["corpus_summary"], indent=2))

    if args.command == "ls-setup":
        if not args.api_key:
            parser.error("ls-setup requires --api-key (copy from Label Studio Account & Settings -> Access Token)")
        res = setup_label_studio_projects(url=args.url, api_key=args.api_key, batch=args.batch, root_dir=root)
        print("[ls-setup]", json.dumps(res, indent=2))

    if args.command == "ls-export":
        if not args.api_key:
            parser.error("ls-export requires --api-key")
        raw_dir = root / "data/exports" / args.version / "raw"
        exported = export_label_studio_projects(url=args.url, api_key=args.api_key, out_dir=raw_dir)
        print("[ls-export] Downloaded:", {k: str(v) for k, v in exported.items()})
        p1_raw, p2_raw = exported.get("p1"), exported.get("p2")
        if p1_raw:
            qc_report = run_qc_checks(p1_raw, p2_raw, out_dir=root / "data/exports" / args.version / "qc")
            print("[qc] Summary:", json.dumps(qc_report, indent=2))
            consensus = root / paths["label_studio_dir"] / "auto_consensus_p1.json"
            p1_res = compile_p1_export(
                p1_raw,
                root / paths["predictions_dir"] / "pages.jsonl",
                root / "data/exports" / args.version,
                args.version,
                consensus_path=consensus if consensus.exists() else None,
            )
            print("[compile-feedback p1]", json.dumps(p1_res, indent=2))
            if p2_raw:
                p2_res = compile_p2_export(
                    p2_raw,
                    root / paths["predictions_dir"] / "pages.jsonl",
                    root / "data/exports" / args.version,
                    args.version,
                    ocr_gt_path=Path(p1_res["ocr_gt_path"]),
                )
                print("[compile-feedback p2]", json.dumps(p2_res, indent=2))

    if args.command == "check-qc":
        if not args.p1_export:
            parser.error("check-qc requires --p1-export")
        qc_dir = root / "data/exports/qc"
        qc_report = run_qc_checks(args.p1_export, args.p2_export, out_dir=qc_dir)
        print("[qc] Report:", json.dumps(qc_report, indent=2))

    if args.command == "compile-feedback":
        if not args.p1_export and not args.p2_export:
            parser.error("compile-feedback requires --p1-export and/or --p2-export")
        out_dir = root / "data/exports" / args.version
        pages_jsonl = root / paths["predictions_dir"] / "pages.jsonl"
        result: dict = {"dataset_version": args.version}
        ocr_gt_path = None
        if args.p1_export:
            default_cons = root / paths["label_studio_dir"] / "auto_consensus_p1.json"
            cons_path = args.consensus_path or (default_cons if default_cons.exists() else None)
            p1_res = compile_p1_export(args.p1_export, pages_jsonl, out_dir, args.version, consensus_path=cons_path)
            result["p1"] = p1_res
            ocr_gt_path = Path(p1_res["ocr_gt_path"])
        if args.p2_export:
            result["p2"] = compile_p2_export(args.p2_export, pages_jsonl, out_dir, args.version, ocr_gt_path=ocr_gt_path)
        print("[compile-feedback]", json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
