"""Annotator quality control (schema hygiene) and Inter-Annotator Agreement (IAA) checker."""

from __future__ import annotations

import json
import re
from collections import Counter
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from pipeline.feedback_compiler import _bbox_iou, _bbox_pct_to_norm

_NON_TEXT_LABELS = {"Signature", "Stamp_Seal"}
_SPAN_RE = re.compile(r"^\s*\d+\s*,\s*\d+\s*$")


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i]
        for j, cb in enumerate(b, 1):
            curr.append(min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = curr
    return prev[-1]


def _cohens_kappa(labels_a: List[str], labels_b: List[str]) -> Optional[float]:
    if not labels_a or len(labels_a) != len(labels_b):
        return None
    n = len(labels_a)
    po = sum(1 for a, b in zip(labels_a, labels_b) if a == b) / n
    ca, cb = Counter(labels_a), Counter(labels_b)
    pe = sum((ca[k] / n) * (cb[k] / n) for k in set(ca) | set(cb))
    if abs(1.0 - pe) < 1e-9:
        return 1.0 if abs(po - 1.0) < 1e-9 else 0.0
    return round((po - pe) / (1.0 - pe), 4)


def _extract_p1_ann_fields(ann: Dict[str, Any]) -> Dict[str, Any]:
    regions: Dict[str, Dict[str, Any]] = {}
    severity: Optional[str] = None
    errors: List[str] = []
    for res in ann.get("result", []):
        rid = str(res.get("id", ""))
        rtype = res.get("type")
        fname = res.get("from_name")
        val = res.get("value", {})
        if rtype == "rectanglelabels" and fname == "region_type":
            r = regions.setdefault(rid, {})
            r["label"] = (val.get("rectanglelabels") or [""])[0]
            r["bbox_norm"] = _bbox_pct_to_norm(val)
        elif rtype == "textarea" and fname == "transcription":
            r = regions.setdefault(rid, {})
            txt = val.get("text") or []
            r["text"] = txt[0] if txt else ""
        elif rtype == "choices" and fname == "error_severity":
            choices = val.get("choices") or []
            severity = choices[0] if choices else None
        elif rtype == "choices" and fname == "error_categories":
            errors = list(val.get("choices") or [])
    return {"regions": regions, "severity": severity, "errors": errors}


def run_qc_checks(
    p1_export_path: Path,
    p2_export_path: Optional[Path] = None,
    out_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Validate schema hygiene and compute multi-annotator IAA on Label Studio exports."""
    p1_tasks = json.loads(p1_export_path.read_text(encoding="utf-8"))
    issues: List[Dict[str, Any]] = []
    sev_pairs_a: List[str] = []
    sev_pairs_b: List[str] = []
    err_jaccards: List[float] = []
    char_sims: List[float] = []
    overlap_tasks = 0
    total_anns = 0

    for task in p1_tasks:
        page_id = task.get("data", {}).get("page_id", task.get("id"))
        anns = [a for a in task.get("annotations", []) if not a.get("was_cancelled", False)]
        parsed_anns: List[Dict[str, Any]] = []

        for ann in anns:
            total_anns += 1
            parsed = _extract_p1_ann_fields(ann)
            parsed_anns.append(parsed)
            if not parsed["severity"]:
                issues.append({"page_id": page_id, "annotation_id": ann.get("id"), "issue": "missing_error_severity"})
            for rid, reg in parsed["regions"].items():
                lbl = reg.get("label", "")
                txt = (reg.get("text") or "").strip()
                if lbl not in _NON_TEXT_LABELS and lbl != "Hallucinated_Text" and not txt:
                    issues.append(
                        {
                            "page_id": page_id,
                            "annotation_id": ann.get("id"),
                            "region_id": rid,
                            "issue": f"empty_transcription_for_{lbl}",
                        }
                    )
            if parsed["severity"] == "S3_Critical" and not (
                {"ERR_NUMERIC", "ERR_TOTAL", "ERR_MISSING", "ERR_ROW_ASSIGN", "ERR_COL_ASSIGN", "ERR_MERGED_CELL", "ERR_HALLUCINATION"}
                & set(parsed["errors"])
            ):
                issues.append(
                    {
                        "page_id": page_id,
                        "annotation_id": ann.get("id"),
                        "issue": "s3_critical_without_matching_error_category",
                    }
                )

        if len(parsed_anns) >= 2:
            overlap_tasks += 1
            for a1, a2 in combinations(parsed_anns, 2):
                if a1["severity"] and a2["severity"]:
                    sev_pairs_a.append(a1["severity"])
                    sev_pairs_b.append(a2["severity"])
                s1, s2 = set(a1["errors"]), set(a2["errors"])
                err_jaccards.append(len(s1 & s2) / max(1, len(s1 | s2)) if (s1 or s2) else 1.0)

                r2_list = list(a2["regions"].values())
                for r1 in a1["regions"].values():
                    b1 = r1.get("bbox_norm")
                    if not b1:
                        continue
                    best_iou, best_r2 = 0.0, None
                    for r2 in r2_list:
                        b2 = r2.get("bbox_norm")
                        if not b2:
                            continue
                        iou = _bbox_iou(b1, b2)
                        if iou > best_iou:
                            best_iou, best_r2 = iou, r2
                    if best_iou >= 0.5 and best_r2 is not None:
                        t1 = (r1.get("text") or "").strip()
                        t2 = (best_r2.get("text") or "").strip()
                        if t1 or t2:
                            dist = _levenshtein(t1, t2)
                            char_sims.append(max(0.0, 1.0 - dist / max(1, len(t1), len(t2))))

    p2_issues: List[Dict[str, Any]] = []
    p2_row_col_agreements: List[int] = []
    p2_total_anns = 0

    if p2_export_path and p2_export_path.exists():
        p2_tasks = json.loads(p2_export_path.read_text(encoding="utf-8"))
        for task in p2_tasks:
            page_id = task.get("data", {}).get("page_id", task.get("id"))
            anns = [a for a in task.get("annotations", []) if not a.get("was_cancelled", False)]
            dims: List[Tuple[int, int]] = []
            for ann in anns:
                p2_total_anns += 1
                regs: Dict[str, Dict[str, Any]] = {}
                for res in ann.get("result", []):
                    rid = str(res.get("id", ""))
                    r = regs.setdefault(rid, {})
                    if res.get("from_name") == "table_elements":
                        r["label"] = (res.get("value", {}).get("rectanglelabels") or [""])[0]
                    elif res.get("from_name") == "cell_span":
                        txt = res.get("value", {}).get("text") or []
                        r["cell_span"] = txt[0] if txt else ""
                n_rows = sum(1 for r in regs.values() if r.get("label") in ("Table_Row", "Table_Header_Row"))
                n_cols = sum(1 for r in regs.values() if r.get("label") == "Table_Col")
                dims.append((n_rows, n_cols))
                if n_rows == 0 or n_cols == 0:
                    p2_issues.append({"page_id": page_id, "annotation_id": ann.get("id"), "issue": "missing_rows_or_cols"})
                for rid, r in regs.items():
                    if r.get("label") == "Merged_Cell" and r.get("cell_span") and not _SPAN_RE.match(r["cell_span"]):
                        p2_issues.append(
                            {
                                "page_id": page_id,
                                "annotation_id": ann.get("id"),
                                "region_id": rid,
                                "issue": f"invalid_cell_span:{r['cell_span']}",
                            }
                        )
            if len(dims) >= 2:
                for d1, d2 in combinations(dims, 2):
                    p2_row_col_agreements.append(int(d1 == d2))

    report = {
        "p1_summary": {
            "tasks_in_export": len(p1_tasks),
            "total_annotations": total_anns,
            "overlap_tasks": overlap_tasks,
            "severity_exact_agreement": round(
                sum(1 for a, b in zip(sev_pairs_a, sev_pairs_b) if a == b) / len(sev_pairs_a), 4
            )
            if sev_pairs_a
            else None,
            "severity_cohens_kappa": _cohens_kappa(sev_pairs_a, sev_pairs_b),
            "error_category_mean_jaccard": round(sum(err_jaccards) / len(err_jaccards), 4) if err_jaccards else None,
            "mean_transcription_similarity": round(sum(char_sims) / len(char_sims), 4) if char_sims else None,
            "hygiene_issue_count": len(issues),
            "hygiene_issues": issues[:50],
        },
        "p2_summary": {
            "total_annotations": p2_total_anns,
            "row_col_exact_agreement": round(sum(p2_row_col_agreements) / len(p2_row_col_agreements), 4)
            if p2_row_col_agreements
            else None,
            "hygiene_issue_count": len(p2_issues),
            "hygiene_issues": p2_issues[:50],
        },
    }

    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / "qc_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        md_lines = [
            "# Phase 2 Annotator QC & IAA Report",
            "",
            "## LS-P1 (OCR Correction & Error Triage)",
            f"- Tasks: {report['p1_summary']['tasks_in_export']} | Annotations: {total_anns} | Overlap tasks: {overlap_tasks}",
            f"- Severity exact agreement: {report['p1_summary']['severity_exact_agreement']} | Cohen's kappa: {report['p1_summary']['severity_cohens_kappa']}",
            f"- Error category mean Jaccard: {report['p1_summary']['error_category_mean_jaccard']}",
            f"- Mean transcription similarity (1-CER): {report['p1_summary']['mean_transcription_similarity']}",
            f"- Hygiene issues: {len(issues)}",
            "",
            "## LS-P2 (Table Structure)",
            f"- Annotations: {p2_total_anns} | Row/Col exact agreement: {report['p2_summary']['row_col_exact_agreement']}",
            f"- Hygiene issues: {len(p2_issues)}",
        ]
        (out_dir / "qc_report.md").write_text("\n".join(md_lines) + "\n", encoding="utf-8")

    return report
