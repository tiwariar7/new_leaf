"""Canonical Phase 1 data schemas for rendered pages and LiteParse structured outputs."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class NormalizedRect(BaseModel):
    """Axis-aligned bounding box in both 72-DPI PDF points and normalized [0, 1] coords."""

    x_pt: float
    y_pt: float
    width_pt: float
    height_pt: float
    x_norm: float
    y_norm: float
    width_norm: float
    height_norm: float

    @classmethod
    def from_points(
        cls,
        x: float,
        y: float,
        width: float,
        height: float,
        page_width: float,
        page_height: float,
    ) -> "NormalizedRect":
        pw = max(page_width, 1e-6)
        ph = max(page_height, 1e-6)
        x_norm = max(0.0, min(1.0, x / pw))
        y_norm = max(0.0, min(1.0, y / ph))
        w_norm = max(0.0, min(1.0 - x_norm, width / pw))
        h_norm = max(0.0, min(1.0 - y_norm, height / ph))
        return cls(
            x_pt=round(x, 3),
            y_pt=round(y, 3),
            width_pt=round(width, 3),
            height_pt=round(height, 3),
            x_norm=round(x_norm, 6),
            y_norm=round(y_norm, 6),
            width_norm=round(w_norm, 6),
            height_norm=round(h_norm, 6),
        )


class SerializedWordBox(BaseModel):
    text: str
    bbox: NormalizedRect


class SerializedTextItem(BaseModel):
    item_index: int
    text: str
    bbox: NormalizedRect
    confidence: Optional[float] = None
    rotation: float = 0.0
    words: List[SerializedWordBox] = Field(default_factory=list)


class SerializedLayoutCell(BaseModel):
    text: str
    bbox: Optional[NormalizedRect] = None
    text_item_indices: List[int] = Field(default_factory=list)


class SerializedLayoutBlock(BaseModel):
    block_index: int
    kind: str
    text: Optional[str] = None
    level: Optional[int] = None
    lines: Optional[List[str]] = None
    bbox: Optional[NormalizedRect] = None
    header: Optional[List[SerializedLayoutCell]] = None
    rows: Optional[List[List[SerializedLayoutCell]]] = None
    text_item_indices: List[int] = Field(default_factory=list)


class PageRenderMeta(BaseModel):
    document_id: str
    page_id: str
    source_pdf: str
    page_number: int
    dpi: int
    width_pt: float
    height_pt: float
    width_px: int
    height_px: int
    rotation_fix_deg: int = 0
    image_rel_path: str
    image_abs_path: str
    image_sha256: str


class PagePrediction(BaseModel):
    document_id: str
    page_id: str
    source_pdf: str
    page_number: int
    width_pt: float
    height_pt: float
    width_px: int
    height_px: int
    image_rel_path: str
    model: str
    model_version: str
    liteparse_version: str
    text: str
    markdown: str
    complexity: Optional[Dict[str, Any]] = None
    text_items: List[SerializedTextItem] = Field(default_factory=list)
    blocks: List[SerializedLayoutBlock] = Field(default_factory=list)


class DocumentPrediction(BaseModel):
    document_id: str
    source_pdf: str
    pdf_sha256: str
    total_pages: int
    model: str
    model_version: str
    liteparse_version: str
    config: Dict[str, Any]
    elapsed_ms: float
    pages: List[PagePrediction] = Field(default_factory=list)


# --- : Human Feedback & Ground-Truth Compilation Schemas ---


class CorrectedRegion(BaseModel):
    region_id: str
    label: str
    bbox_norm: List[float]
    predicted_text: Optional[str] = None
    corrected_text: Optional[str] = None
    action: str  # unchanged | modified | added | hallucinated | non_text
    is_critical_numeric: bool = False


class OCRGroundTruthPage(BaseModel):
    dataset_version: str
    document_id: str
    page_id: str
    page_number: int
    source_pdf: str
    image_rel_path: str
    width_px: int
    height_px: int
    baseline_model: str
    annotator_id: str
    annotation_id: int
    lead_time_sec: Optional[float] = None
    error_categories: List[str] = Field(default_factory=list)
    error_severity: str
    annotation_notes: Optional[str] = None
    regions: List[CorrectedRegion] = Field(default_factory=list)
    summary_counts: Dict[str, int] = Field(default_factory=dict)


class SolvedTableCell(BaseModel):
    row: int
    col: int
    rowspan: int = 1
    colspan: int = 1
    is_header: bool = False
    text: str = ""
    bbox_norm: Optional[List[float]] = None
    source: str = "ocr_snap"  # ocr_snap | cell_override | merged_cell | empty


class SolvedTable(BaseModel):
    table_id: str
    bbox_norm: List[float]
    num_rows: int
    num_cols: int
    header_row_indices: List[int] = Field(default_factory=list)
    cells: List[SolvedTableCell] = Field(default_factory=list)
    html: str


class TableGroundTruthPage(BaseModel):
    dataset_version: str
    document_id: str
    page_id: str
    page_number: int
    source_pdf: str
    annotator_id: str
    annotation_id: int
    tables: List[SolvedTable] = Field(default_factory=list)



# --- Phase 2: Human Feedback & Ground-Truth Compilation Schemas ---


class CorrectedRegion(BaseModel):
    region_id: str
    label: str
    bbox_norm: List[float]
    predicted_text: Optional[str] = None
    corrected_text: Optional[str] = None
    action: str  # unchanged | modified | added | hallucinated | non_text
    is_critical_numeric: bool = False


class OCRGroundTruthPage(BaseModel):
    dataset_version: str
    document_id: str
    page_id: str
    page_number: int
    source_pdf: str
    image_rel_path: str
    width_px: int
    height_px: int
    baseline_model: str
    annotator_id: str
    annotation_id: int
    lead_time_sec: Optional[float] = None
    error_categories: List[str] = Field(default_factory=list)
    error_severity: str
    annotation_notes: Optional[str] = None
    regions: List[CorrectedRegion] = Field(default_factory=list)
    summary_counts: Dict[str, int] = Field(default_factory=dict)


class SolvedTableCell(BaseModel):
    row: int
    col: int
    rowspan: int = 1
    colspan: int = 1
    is_header: bool = False
    text: str = ""
    bbox_norm: Optional[List[float]] = None
    source: str = "ocr_snap"  # ocr_snap | cell_override | merged_cell | empty


class SolvedTable(BaseModel):
    table_id: str
    bbox_norm: List[float]
    num_rows: int
    num_cols: int
    header_row_indices: List[int] = Field(default_factory=list)
    cells: List[SolvedTableCell] = Field(default_factory=list)
    html: str


class TableGroundTruthPage(BaseModel):
    dataset_version: str
    document_id: str
    page_id: str
    page_number: int
    source_pdf: str
    annotator_id: str
    annotation_id: int
    tables: List[SolvedTable] = Field(default_factory=list)

