"""Generate local Label Studio import-ready task JSONs with LiteParse pre-annotations and  pilot queues."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from pipeline.ocr.liteparse_runner import load_pipeline_config
from pipeline.schemas import NormalizedRect, PagePrediction

_KEY_FIELD_RE = re.compile(
    r"\b(?:S\.?O\.?\s*NO|PO\s*NO|DRAWING\s*NO|NDT\s*REPORT|REPORT\s*NO|GSTIN|PAN|PART\s*NO|SR\.?\s*NO|REF\s*:|QAP\s*:)\b",
    re.IGNORECASE,
)
_NUMERIC_TOTAL_RE = re.compile(
    r"(?:±\s*\d|\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|(?:TOTAL|QTY|AMOUNT|TAX|GST|MASS|LENGTH)\b.*\d|\b\d+\.\d{2,}\b)",
    re.IGNORECASE,
)


def _ls_box_value(bbox: NormalizedRect, label: str) -> Dict[str, Any]:
    return {
        "x": round(bbox.x_norm * 100.0, 4),
        "y": round(bbox.y_norm * 100.0, 4),
        "width": round(bbox.width_norm * 100.0, 4),
        "height": round(bbox.height_norm * 100.0, 4),
        "rotation": 0,
        "rectanglelabels": [label],
    }


def _block_label_for_item(page: PagePrediction) -> Dict[int, str]:
    """Map text_item_index -> Label Studio region label using LayoutBlocks."""
    mapping: Dict[int, str] = {}
    for blk in page.blocks:
        if blk.kind == "page_header":
            lbl = "Header"
        elif blk.kind == "page_footer":
            lbl = "Footer"
        elif blk.kind in ("table", "merged_table", "grid_fallback"):
            lbl = "Table_Region"
        else:
            lbl = "Text_Line"
        for idx in blk.text_item_indices:
            mapping[idx] = lbl
    return mapping


def _infer_region_label(text: str, block_label: str) -> str:
    """Promote high-value identifier/numerical lines to Key_Field or Numeric_Total."""
    if block_label in ("Header", "Footer"):
        return block_label
    if _KEY_FIELD_RE.search(text):
        return "Key_Field"
    if _NUMERIC_TOTAL_RE.search(text):
        return "Numeric_Total"
    return block_label


def build_p1_task(page: PagePrediction, local_files_prefix: str) -> Dict[str, Any]:
    """Build a Label Studio LS-P1 OCR correction task with paired bbox + transcription pre-annotations."""
    item_labels = _block_label_for_item(page)
    results: List[Dict[str, Any]] = []

    for item in page.text_items:
        text = (item.text or "").strip()
        if not text:
            continue
        if item.bbox.width_norm <= 0.0005 or item.bbox.height_norm <= 0.0005:
            continue
        region_id = f"ti_{page.page_number}_{item.item_index}"
        base_lbl = item_labels.get(item.item_index, "Text_Line")
        label = _infer_region_label(text, base_lbl)
        results.append(
            {
                "id": region_id,
                "from_name": "region_type",
                "to_name": "image",
                "type": "rectanglelabels",
                "origin": "prediction",
                "original_width": page.width_px,
                "original_height": page.height_px,
                "image_rotation": 0,
                "value": _ls_box_value(item.bbox, label),
                "score": item.confidence if item.confidence is not None else 1.0,
            }
        )
        results.append(
            {
                "id": region_id,
                "from_name": "transcription",
                "to_name": "image",
                "type": "textarea",
                "origin": "prediction",
                "original_width": page.width_px,
                "original_height": page.height_px,
                "image_rotation": 0,
                "value": {
                    "x": round(item.bbox.x_norm * 100.0, 4),
                    "y": round(item.bbox.y_norm * 100.0, 4),
                    "width": round(item.bbox.width_norm * 100.0, 4),
                    "height": round(item.bbox.height_norm * 100.0, 4),
                    "rotation": 0,
                    "text": [text],
                },
            }
        )

    for blk in page.blocks:
        if blk.kind in ("table", "merged_table", "grid_fallback") and blk.bbox is not None:
            results.append(
                {
                    "id": f"tbl_{page.page_number}_{blk.block_index}",
                    "from_name": "region_type",
                    "to_name": "image",
                    "type": "rectanglelabels",
                    "origin": "prediction",
                    "original_width": page.width_px,
                    "original_height": page.height_px,
                    "image_rotation": 0,
                    "value": _ls_box_value(blk.bbox, "Table_Region"),
                }
            )

    confs = [t.confidence for t in page.text_items if t.confidence is not None]
    avg_conf = round(sum(confs) / len(confs), 4) if confs else 1.0

    return {
        "data": {
            "image": f"{local_files_prefix}pages/{page.image_rel_path}",
            "document_id": page.document_id,
            "page_id": page.page_id,
            "page_number": page.page_number,
            "source_pdf": page.source_pdf,
            "baseline_model": f"{page.model}@{page.model_version}",
        },
        "meta": {
            "width_px": page.width_px,
            "height_px": page.height_px,
            "width_pt": page.width_pt,
            "height_pt": page.height_pt,
        },
        "predictions": [
            {
                "model_version": f"{page.model}_{page.model_version}_liteparse_{page.liteparse_version}",
                "score": avg_conf,
                "result": results,
            }
        ],
    }


def build_p2_table_task(page: PagePrediction, local_files_prefix: str) -> Optional[Dict[str, Any]]:
    """Build a Label Studio LS-P2 table-structure task for pages containing tables."""
    table_blocks = [b for b in page.blocks if b.kind in ("table", "merged_table", "grid_fallback")]
    if not table_blocks:
        return None

    results: List[Dict[str, Any]] = []
    for blk in table_blocks:
        if blk.bbox is not None:
            results.append(
                {
                    "id": f"tbl_{page.page_number}_{blk.block_index}",
                    "from_name": "table_elements",
                    "to_name": "image",
                    "type": "rectanglelabels",
                    "origin": "prediction",
                    "original_width": page.width_px,
                    "original_height": page.height_px,
                    "image_rotation": 0,
                    "value": _ls_box_value(blk.bbox, "Table"),
                }
            )
        for r_idx, row in enumerate(blk.rows or []):
            for c_idx, cell in enumerate(row):
                if cell.bbox is None or not cell.text.strip():
                    continue
                cid = f"cell_{page.page_number}_{blk.block_index}_{r_idx}_{c_idx}"
                results.append(
                    {
                        "id": cid,
                        "from_name": "table_elements",
                        "to_name": "image",
                        "type": "rectanglelabels",
                        "origin": "prediction",
                        "original_width": page.width_px,
                        "original_height": page.height_px,
                        "image_rotation": 0,
                        "value": _ls_box_value(cell.bbox, "Cell_Override"),
                    }
                )
                results.append(
                    {
                        "id": cid,
                        "from_name": "cell_text",
                        "to_name": "image",
                        "type": "textarea",
                        "origin": "prediction",
                        "original_width": page.width_px,
                        "original_height": page.height_px,
                        "image_rotation": 0,
                        "value": {
                            "x": round(cell.bbox.x_norm * 100.0, 4),
                            "y": round(cell.bbox.y_norm * 100.0, 4),
                            "width": round(cell.bbox.width_norm * 100.0, 4),
                            "height": round(cell.bbox.height_norm * 100.0, 4),
                            "rotation": 0,
                            "text": [cell.text],
                        },
                    }
                )

    return {
        "data": {
            "image": f"{local_files_prefix}pages/{page.image_rel_path}",
            "document_id": page.document_id,
            "page_id": page.page_id,
            "page_number": page.page_number,
            "source_pdf": page.source_pdf,
        },
        "predictions": [
            {
                "model_version": f"{page.model}_{page.model_version}_tables",
                "result": results,
            }
        ],
    }


def _load_priority_page_ids(baseline_report_path: Path) -> List[str]:
    if not baseline_report_path.exists():
        return []
    report = json.loads(baseline_report_path.read_text(encoding="utf-8"))
    return [row["page_id"] for row in report.get("priority_annotation_queue_top15", [])]


def export_label_studio_tasks(root_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Compile pages.jsonl into full +  pilot Label Studio task JSONs and import guide."""
    root = (root_dir or Path.cwd()).resolve()
    cfg = load_pipeline_config(root / "configs/pipeline.yaml")
    paths = cfg["paths"]
    ls_cfg = cfg.get("label_studio", {})
    prefix = str(ls_cfg.get("local_files_prefix", "/data/local-files/?d="))

    pages_jsonl = (root / paths["predictions_dir"] / "pages.jsonl").resolve()
    if not pages_jsonl.exists():
        raise FileNotFoundError(f"Missing baseline predictions at {pages_jsonl}. Run baseline OCR first.")

    out_dir = (root / paths["label_studio_dir"]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    pages_root = (root / paths["pages_dir"]).resolve()
    document_root = pages_root.parent
    baseline_report_path = (root / paths["baseline_eval_dir"] / "baseline_report.json").resolve()
    priority_ids = _load_priority_page_ids(baseline_report_path)
    priority_rank = {pid: i for i, pid in enumerate(priority_ids)}

    p1_tasks: List[Dict[str, Any]] = []
    p2_tasks: List[Dict[str, Any]] = []

    for line in pages_jsonl.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        pg = PagePrediction.model_validate_json(line)
        p1_tasks.append(build_p1_task(pg, prefix))
        p2 = build_p2_table_task(pg, prefix)
        if p2 is not None:
            p2_tasks.append(p2)

    p1_path = out_dir / "ls_p1_tasks.json"
    p2_path = out_dir / "ls_p2_table_tasks.json"
    p1_path.write_text(json.dumps(p1_tasks, indent=2, ensure_ascii=False), encoding="utf-8")
    p2_path.write_text(json.dumps(p2_tasks, indent=2, ensure_ascii=False), encoding="utf-8")

    #  Pilot 15 & 15% IAA calibration slice
    p1_by_id = {t["data"]["page_id"]: t for t in p1_tasks}
    p2_by_id = {t["data"]["page_id"]: t for t in p2_tasks}

    p1_pilot = [p1_by_id[pid] for pid in priority_ids if pid in p1_by_id] if priority_ids else p1_tasks[:15]
    p2_pilot = [p2_by_id[pid] for pid in priority_ids if pid in p2_by_id] if priority_ids else p2_tasks[:15]

    # Deterministic 15% calibration slice stratified across documents (~11 pages)
    iaa_tasks: List[Dict[str, Any]] = []
    seen_docs: Set[str] = set()
    for t in p1_pilot:
        doc_id = t["data"]["document_id"]
        if doc_id not in seen_docs or len(iaa_tasks) < 11:
            iaa_tasks.append(t)
            seen_docs.add(doc_id)
        if len(iaa_tasks) >= 11:
            break

    p1_pilot_path = out_dir / "ls_p1_pilot15.json"
    p2_pilot_path = out_dir / "ls_p2_pilot15.json"
    iaa_path = out_dir / "ls_p1_iaa_overlap.json"
    p1_pilot_path.write_text(json.dumps(p1_pilot, indent=2, ensure_ascii=False), encoding="utf-8")
    p2_pilot_path.write_text(json.dumps(p2_pilot, indent=2, ensure_ascii=False), encoding="utf-8")
    iaa_path.write_text(json.dumps(iaa_tasks, indent=2, ensure_ascii=False), encoding="utf-8")

    guide = f"""# Label Studio Manual Import Guide (Phase 1 & )

This workflow avoids the raw-PDF `$undefined$` rendering bug seen in Project 4 by serving **pre-rendered 300-DPI PNG page images** with pre-annotated LiteParse bounding boxes and transcriptions.
Read `configs/label_studio/ANNOTATION_GUIDELINES.md` before annotating.

## 1. Start Label Studio with Local File Serving Enabled (PowerShell)
`LABEL_STUDIO_LOCAL_FILES_DOCUMENT_ROOT` must be a **parent directory** of the Cloud Storage folder (`data\\pages`), otherwise Label Studio rejects it for security reasons.
```powershell
$env:LABEL_STUDIO_LOCAL_FILES_SERVING_ENABLED="true"
$env:LABEL_STUDIO_LOCAL_FILES_DOCUMENT_ROOT="{document_root}"
& "{root}\\.venv\\Scripts\\label-studio.exe" start
```

## 2. Create Project `LS-P1: OCR Correction & Error Triage`
1. Create a new project in Label Studio UI.
2. Under **Settings -> Cloud Storage -> Add Source Storage -> Local files**:
   - **Absolute local path:** `{pages_root}` (subdirectory of `{document_root}`; leave **Treat every bucket object as a source file** unchecked so you import pre-annotated tasks from JSON)
3. Under **Settings -> Labeling Interface -> Code**, paste:
   - `configs/label_studio/p1_ocr_correction.xml`
4. **Start with the Pilot Batch:** Import `data/label_studio/ls_p1_pilot15.json` ({len(p1_pilot)} priority pages), then scale to `ls_p1_tasks.json` ({len(p1_tasks)} pages).
5. Use `ls_p1_iaa_overlap.json` ({len(iaa_tasks)} pages) with `overlap = 2` annotators to calibrate agreement.

## 3. Create Project `LS-P2: Complex Table Structure`
1. Create a second project and add the same Local Storage path (`{pages_root}`).
2. Paste `configs/label_studio/p2_table_structure.xml` into **Labeling Interface -> Code**.
3. Import `data/label_studio/ls_p2_pilot15.json` ({len(p2_pilot)} priority table pages) first, then `ls_p2_table_tasks.json` ({len(p2_tasks)} pages).

## 4. Export & Compile  Ground Truth
After annotating, export JSON from both projects and run:
```powershell
& "{root}\\.venv\\Scripts\\python.exe" -m pipeline.main check-qc --p1-export path\\to\\p1_export.json --p2-export path\\to\\p2_export.json
& "{root}\\.venv\\Scripts\\python.exe" -m pipeline.main compile-feedback --p1-export path\\to\\p1_export.json --p2-export path\\to\\p2_export.json --version v20261127_01
```
"""
    guide_path = out_dir / "IMPORT_GUIDE.md"
    guide_path.write_text(guide, encoding="utf-8")

    return {
        "p1_tasks": len(p1_tasks),
        "p2_table_tasks": len(p2_tasks),
        "p1_pilot15": len(p1_pilot),
        "p2_pilot15": len(p2_pilot),
        "iaa_overlap_tasks": len(iaa_tasks),
        "priority_ordered": bool(priority_rank),
        "p1_path": str(p1_path),
        "p2_path": str(p2_path),
        "p1_pilot_path": str(p1_pilot_path),
        "p2_pilot_path": str(p2_pilot_path),
        "iaa_path": str(iaa_path),
        "guide_path": str(guide_path),
    }


def main() -> None:
    summary = export_label_studio_tasks(Path.cwd())
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
