"""PDF-to-PNG rendering and orientation alignment utilities."""

from __future__ import annotations

import hashlib
import io
import re
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pypdfium2 as pdfium
from PIL import Image

from pipeline.schemas import PageRenderMeta


def slugify_doc_id(pdf_path: Path) -> str:
    """Create a deterministic filesystem-safe document_id from PDF filename."""
    stem = re.sub(r"[^A-Za-z0-9]+", "_", pdf_path.stem).strip("_").lower()
    return stem or "document"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _ink_density_score(img_gray: Image.Image, items: Sequence[object], page_w: float, page_h: float) -> float:
    """Score how well dark pixels align with predicted TextItem bounding boxes."""
    if not items or page_w <= 0 or page_h <= 0:
        return 0.0
    arr = np.asarray(img_gray)
    h_px, w_px = arr.shape
    sx = w_px / page_w
    sy = h_px / page_h
    scores: List[float] = []
    for item in items[:20]:
        text = getattr(item, "text", "") or ""
        if not text.strip():
            continue
        x0 = max(0, int(getattr(item, "x", 0.0) * sx))
        y0 = max(0, int(getattr(item, "y", 0.0) * sy))
        x1 = min(w_px, int((getattr(item, "x", 0.0) + getattr(item, "width", 0.0)) * sx))
        y1 = min(h_px, int((getattr(item, "y", 0.0) + getattr(item, "height", 0.0)) * sy))
        if x1 <= x0 + 2 or y1 <= y0 + 2:
            continue
        crop = arr[y0:y1, x0:x1]
        scores.append(float((crop < 190).mean()))
    return float(np.mean(scores)) if scores else 0.0


def align_image_to_parsed_page(
    image_bytes: bytes,
    page_width_pt: float,
    page_height_pt: float,
    text_items: Sequence[object],
) -> Tuple[Image.Image, int]:
    """Ensure rendered PNG matches ParsedPage orientation (handles LiteParse auto-rotation).

    Returns (aligned_rgb_image, applied_ccw_degrees).
    """
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    w_px, h_px = img.size
    shot_landscape = w_px > h_px
    page_landscape = page_width_pt > page_height_pt

    if shot_landscape != page_landscape:
        candidates = [
            (90, img.transpose(Image.Transpose.ROTATE_90)),
            (270, img.transpose(Image.Transpose.ROTATE_270)),
        ]
    else:
        candidates = [
            (0, img),
            (180, img.transpose(Image.Transpose.ROTATE_180)),
        ]

    if not text_items:
        return candidates[0][1], candidates[0][0]

    best_deg, best_img, best_score = candidates[0][0], candidates[0][1], -1.0
    for deg, cand in candidates:
        score = _ink_density_score(cand.convert("L"), text_items, page_width_pt, page_height_pt)
        if score > best_score:
            best_deg, best_img, best_score = deg, cand, score

    # Only flip 180 deg if it beats 0 deg meaningfully (avoid noise flips on blank pages)
    if best_deg == 180:
        score_0 = _ink_density_score(candidates[0][1].convert("L"), text_items, page_width_pt, page_height_pt)
        if best_score < score_0 + 0.03:
            return candidates[0][1], 0

    return best_img, best_deg


def save_aligned_page_png(
    image_bytes: bytes,
    out_path: Path,
    document_id: str,
    source_pdf: str,
    page_number: int,
    dpi: int,
    page_width_pt: float,
    page_height_pt: float,
    text_items: Sequence[object],
    pages_root: Path,
) -> PageRenderMeta:
    """Align PNG bytes to ParsedPage coords, save to disk, and return PageRenderMeta."""
    aligned, rot_deg = align_image_to_parsed_page(
        image_bytes=image_bytes,
        page_width_pt=page_width_pt,
        page_height_pt=page_height_pt,
        text_items=text_items,
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    buf = io.BytesIO()
    aligned.save(buf, format="PNG", optimize=False)
    png_bytes = buf.getvalue()
    out_path.write_bytes(png_bytes)

    w_px, h_px = aligned.size
    rel_path = out_path.relative_to(pages_root).as_posix()
    return PageRenderMeta(
        document_id=document_id,
        page_id=f"{document_id}_p{page_number:04d}",
        source_pdf=source_pdf,
        page_number=page_number,
        dpi=dpi,
        width_pt=round(page_width_pt, 3),
        height_pt=round(page_height_pt, 3),
        width_px=w_px,
        height_px=h_px,
        rotation_fix_deg=rot_deg,
        image_rel_path=rel_path,
        image_abs_path=str(out_path.resolve()),
        image_sha256=sha256_bytes(png_bytes),
    )


def render_pdf_pages_pypdfium(
    pdf_path: Path,
    pages_root: Path,
    dpi: int = 300,
    page_numbers: Optional[Iterable[int]] = None,
) -> List[PageRenderMeta]:
    """Standalone pypdfium2 PDF-to-PNG renderer (used when rendering without LiteParse)."""
    doc_id = slugify_doc_id(pdf_path)
    doc = pdfium.PdfDocument(str(pdf_path))
    total = len(doc)
    targets = list(page_numbers) if page_numbers is not None else list(range(1, total + 1))
    scale = dpi / 72.0
    metas: List[PageRenderMeta] = []

    for page_num in targets:
        page = doc[page_num - 1]
        w_pt, h_pt = page.get_size()
        pil_img = page.render(scale=scale).to_pil().convert("RGB")
        out_path = pages_root / doc_id / f"p{page_num:04d}.png"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG", optimize=False)
        png_bytes = buf.getvalue()
        out_path.write_bytes(png_bytes)
        w_px, h_px = pil_img.size
        metas.append(
            PageRenderMeta(
                document_id=doc_id,
                page_id=f"{doc_id}_p{page_num:04d}",
                source_pdf=pdf_path.name,
                page_number=page_num,
                dpi=dpi,
                width_pt=round(w_pt, 3),
                height_pt=round(h_pt, 3),
                width_px=w_px,
                height_px=h_px,
                rotation_fix_deg=0,
                image_rel_path=out_path.relative_to(pages_root).as_posix(),
                image_abs_path=str(out_path.resolve()),
                image_sha256=sha256_bytes(png_bytes),
            )
        )
    doc.close()
    return metas
