"""Automated OCRia-nano-1-only self-consistency pre-annotation and table grid band generation."""

from __future__ import annotations

import hashlib
import html
import json
import re
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
from liteparse import LiteParse

from pipeline.labelling import _block_label_for_item, _infer_region_label
from pipeline.ocr.liteparse_runner import load_pipeline_config
from pipeline.schemas import PagePrediction

_DIGIT_RE = re.compile(r"\d+")


def _norm_text(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def _iou(a: List[float], b: List[float]) -> float:
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if inter <= 0.0:
        return 0.0
    return inter / max(1e-9, a[2] * a[3] + b[2] * b[3] - inter)


def _select_smart12_pages(pages: List[PagePrediction], baseline_report_path: Path) -> List[PagePrediction]:
    """Select 12 diverse, high-signal pages across all documents instead of 50 repetitive pages."""
    by_id = {p.page_id: p for p in pages}
    selected_ids: List[str] = []

    for p in pages:
        if p.document_id in ("page_111_to_114_x_ray_test_report_for_throat_insert", "3_wt_ht_214_54_nos"):
            if p.page_id not in selected_ids:
                selected_ids.append(p.page_id)

    priority_rows = []
    if baseline_report_path.exists():
        report = json.loads(baseline_report_path.read_text(encoding="utf-8"))
        priority_rows = report.get("priority_annotation_queue_top15", [])

    by_doc: Dict[str, List[PagePrediction]] = {}
    for p in pages:
        by_doc.setdefault(p.document_id, []).append(p)

    for doc_id, doc_pages in sorted(by_doc.items()):
        if any(by_id[pid].document_id == doc_id for pid in selected_ids):
            continue
        worst = min(
            doc_pages,
            key=lambda pg: (
                sum(t.confidence for t in pg.text_items if t.confidence is not None)
                / max(1, sum(1 for t in pg.text_items if t.confidence is not None))
            ),
        )
        selected_ids.append(worst.page_id)

    for row in priority_rows:
        if len(selected_ids) >= 12:
            break
        pid = row["page_id"]
        if pid in by_id and pid not in selected_ids:
            selected_ids.append(pid)

    return [by_id[pid] for pid in selected_ids[:12]]


def _enhance_scan_image(src_png: Path, dst_png: Path) -> None:
    """Apply lightweight CLAHE contrast + gentle unsharp masking for scan enhancement."""
    img = cv2.imread(str(src_png), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read PNG: {src_png}")
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(img)
    blur = cv2.GaussianBlur(enhanced, (0, 0), sigmaX=1.0)
    sharpened = cv2.addWeighted(enhanced, 1.3, blur, -0.3, 0)
    cv2.imwrite(str(dst_png), sharpened)


def _run_ocria_enhanced_on_page(
    lp_parser: LiteParse,
    img_path: Path,
    tmp_dir: Path,
    page_id: str,
) -> Tuple[List[Dict[str, Any]], str]:
    """Run OCRia-nano-1 on a CLAHE-enhanced PNG copy and return normalized items + markdown."""
    enh_png = tmp_dir / f"{page_id}_enh.png"
    _enhance_scan_image(img_path, enh_png)
    res = lp_parser.parse(str(enh_png))
    if not res.pages:
        return [], ""
    pg = res.pages[0]
    pw, ph = max(1e-6, float(pg.width)), max(1e-6, float(pg.height))
    items: List[Dict[str, Any]] = []
    for idx, ti in enumerate(pg.text_items):
        txt = _norm_text(ti.text)
        if not txt:
            continue
        items.append(
            {
                "idx": idx,
                "text": txt,
                "score": float(ti.confidence) if ti.confidence is not None else 1.0,
                "bbox_norm": [
                    round(max(0.0, min(1.0, ti.x / pw)), 6),
                    round(max(0.0, min(1.0, ti.y / ph)), 6),
                    round(max(0.0, min(1.0, ti.width / pw)), 6),
                    round(max(0.0, min(1.0, ti.height / ph)), 6),
                ],
            }
        )
    return items, (pg.markdown or pg.text or "")


def _pct_box(b: List[float], label: str) -> Dict[str, Any]:
    return {
        "x": round(b[0] * 100.0, 4),
        "y": round(b[1] * 100.0, 4),
        "width": round(b[2] * 100.0, 4),
        "height": round(b[3] * 100.0, 4),
        "rotation": 0,
        "rectanglelabels": [label],
    }


def _pct_text(b: List[float], text: str) -> Dict[str, Any]:
    return {
        "x": round(b[0] * 100.0, 4),
        "y": round(b[1] * 100.0, 4),
        "width": round(b[2] * 100.0, 4),
        "height": round(b[3] * 100.0, 4),
        "rotation": 0,
        "text": [text],
    }


def _build_auto_p1_tasks(
    page: PagePrediction,
    enh_items: List[Dict[str, Any]],
    local_files_prefix: str,
) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """Compare OCRia-nano-1 baseline vs OCRia-nano-1 enhanced to build full + focus tasks."""
    item_labels = _block_label_for_item(page)
    full_results: List[Dict[str, Any]] = []
    focus_results: List[Dict[str, Any]] = []
    consensus_regions: List[Dict[str, Any]] = []
    disagreements: List[str] = []
    err_cats: set[str] = set()
    matched_enh: set[int] = set()

    for ti in page.text_items:
        txt = _norm_text(ti.text)
        if not txt:
            continue
        b = [ti.bbox.x_norm, ti.bbox.y_norm, ti.bbox.width_norm, ti.bbox.height_norm]
        if b[2] <= 0.0005 or b[3] <= 0.0005:
            continue

        best_iou, best_e = 0.0, None
        for e in enh_items:
            iou = _iou(b, e["bbox_norm"])
            if iou > best_iou:
                best_iou, best_e = iou, e
        if best_e is not None and best_iou >= 0.25:
            matched_enh.add(best_e["idx"])

        base_lbl = item_labels.get(ti.item_index, "Text_Line")
        label = _infer_region_label(txt, base_lbl)
        conf = ti.confidence if ti.confidence is not None else 1.0

        enh_txt = best_e["text"] if best_e else None
        exact_agree = enh_txt is not None and enh_txt == txt and conf >= 0.92
        numeric_disagree = enh_txt is not None and _DIGIT_RE.findall(txt) != _DIGIT_RE.findall(enh_txt)

        if not exact_agree and enh_txt is not None and best_iou >= 0.35 and enh_txt != txt:
            if numeric_disagree:
                err_cats.add("ERR_NUMERIC")
            else:
                err_cats.add("ERR_CHAR")
            disagreements.append(f"[{label}] Raw='{txt}' vs Enhanced='{enh_txt}'")
        elif conf < 0.80:
            err_cats.add("ERR_SCAN_QUALITY")

        rid = f"ti_{page.page_number}_{ti.item_index}"
        box_res = {
            "id": rid,
            "from_name": "region_type",
            "to_name": "image",
            "type": "rectanglelabels",
            "origin": "prediction",
            "original_width": page.width_px,
            "original_height": page.height_px,
            "image_rotation": 0,
            "value": _pct_box(b, label),
            "score": conf,
        }
        txt_res = {
            "id": rid,
            "from_name": "transcription",
            "to_name": "image",
            "type": "textarea",
            "origin": "prediction",
            "original_width": page.width_px,
            "original_height": page.height_px,
            "image_rotation": 0,
            "value": _pct_text(b, txt),
        }
        full_results.extend([box_res, txt_res])

        if exact_agree and label not in ("Key_Field", "Numeric_Total", "Header", "Footer"):
            consensus_regions.append(
                {
                    "region_id": rid,
                    "label": label,
                    "bbox_norm": b,
                    "predicted_text": txt,
                    "corrected_text": txt,
                    "action": "unchanged",
                    "is_critical_numeric": False,
                }
            )
        else:
            focus_results.extend([box_res, txt_res])

    # Auto-add Missing_Text boxes discovered by enhanced OCRia-nano-1 pass
    missing_added = 0
    for e in enh_items:
        if e["idx"] in matched_enh or e["score"] < 0.70:
            continue
        eb = e["bbox_norm"]
        if any(
            _iou(eb, [ti.bbox.x_norm, ti.bbox.y_norm, ti.bbox.width_norm, ti.bbox.height_norm]) >= 0.15
            for ti in page.text_items
        ):
            continue
        if len(e["text"]) < 2:
            continue
        missing_added += 1
        err_cats.add("ERR_MISSING")
        rid = f"auto_miss_{page.page_number}_{e['idx']}"
        pair = [
            {
                "id": rid,
                "from_name": "region_type",
                "to_name": "image",
                "type": "rectanglelabels",
                "origin": "prediction",
                "original_width": page.width_px,
                "original_height": page.height_px,
                "image_rotation": 0,
                "value": _pct_box(eb, "Missing_Text"),
                "score": round(e["score"], 4),
            },
            {
                "id": rid,
                "from_name": "transcription",
                "to_name": "image",
                "type": "textarea",
                "origin": "prediction",
                "original_width": page.width_px,
                "original_height": page.height_px,
                "image_rotation": 0,
                "value": _pct_text(eb, e["text"]),
            },
        ]
        full_results.extend(pair)
        focus_results.extend(pair)

    if "ERR_NUMERIC" in err_cats or missing_added >= 3:
        sev = "S3_Critical"
    elif err_cats:
        sev = "S2_Major"
    else:
        sev = "S0_Cosmetic"

    meta_results: List[Dict[str, Any]] = []
    if err_cats:
        meta_results.append(
            {
                "id": "auto_err_cats",
                "from_name": "error_categories",
                "to_name": "image",
                "type": "choices",
                "origin": "prediction",
                "value": {"choices": sorted(err_cats)},
            }
        )
    meta_results.append(
        {
            "id": "auto_err_sev",
            "from_name": "error_severity",
            "to_name": "image",
            "type": "choices",
            "origin": "prediction",
            "value": {"choices": [sev]},
        }
    )
    if disagreements or missing_added:
        note_text = (
            f"OCRia-nano-1 self-consistency: {missing_added} enhanced-only Missing_Text candidates; "
            f"{len(disagreements)} stability disagreements.\n" + "\n".join(disagreements[:12])
        )
        meta_results.append(
            {
                "id": "auto_notes",
                "from_name": "annotation_notes",
                "to_name": "image",
                "type": "textarea",
                "origin": "prediction",
                "value": {"text": [note_text]},
            }
        )

    base_data = {
        "image": f"{local_files_prefix}pages/{page.image_rel_path}",
        "document_id": page.document_id,
        "page_id": page.page_id,
        "page_number": page.page_number,
        "source_pdf": page.source_pdf,
        "baseline_model": f"{page.model}@{page.model_version}",
        "auto_consensus_skipped": len(consensus_regions),
    }
    base_meta = {
        "width_px": page.width_px,
        "height_px": page.height_px,
        "width_pt": page.width_pt,
        "height_pt": page.height_pt,
    }
    full_task = {
        "data": base_data,
        "meta": base_meta,
        "predictions": [{"model_version": "ocria_nano_self_consistency_v1", "result": full_results + meta_results}],
    }
    focus_task = {
        "data": base_data,
        "meta": base_meta,
        "predictions": [{"model_version": "ocria_nano_focus_v1", "result": focus_results + meta_results}],
    }
    return full_task, focus_task, consensus_regions


def _build_auto_p2_table_task(page: PagePrediction, local_files_prefix: str) -> Optional[Dict[str, Any]]:
    """Auto-generate Table, Table_Header_Row, Table_Row, and Table_Col bands from OCRia-nano LayoutBlock cells."""
    table_blocks = [b for b in page.blocks if b.kind in ("table", "merged_table", "grid_fallback")]
    if not table_blocks:
        return None

    results: List[Dict[str, Any]] = []
    for blk in table_blocks:
        if blk.bbox is None:
            continue
        tb = [blk.bbox.x_norm, blk.bbox.y_norm, blk.bbox.width_norm, blk.bbox.height_norm]
        results.append(
            {
                "id": f"tbl_{page.page_number}_{blk.block_index}",
                "from_name": "table_elements",
                "to_name": "image",
                "type": "rectanglelabels",
                "origin": "prediction",
                "original_width": page.width_px,
                "original_height": page.height_px,
                "image_rotation": 0,
                "value": _pct_box(tb, "Table"),
            }
        )

        all_rows = ([] if not blk.header else [blk.header]) + (blk.rows or [])
        n_hdr = 1 if blk.header else 0
        col_x0s: Dict[int, List[float]] = {}
        col_x1s: Dict[int, List[float]] = {}

        for r_idx, row in enumerate(all_rows):
            ys0, ys1 = [], []
            for c_idx, cell in enumerate(row):
                if cell.bbox is None:
                    continue
                ys0.append(cell.bbox.y_norm)
                ys1.append(cell.bbox.y_norm + cell.bbox.height_norm)
                col_x0s.setdefault(c_idx, []).append(cell.bbox.x_norm)
                col_x1s.setdefault(c_idx, []).append(cell.bbox.x_norm + cell.bbox.width_norm)
            if ys0 and ys1:
                ry0, ry1 = min(ys0), max(ys1)
                lbl = "Table_Header_Row" if r_idx < n_hdr else "Table_Row"
                results.append(
                    {
                        "id": f"row_{page.page_number}_{blk.block_index}_{r_idx}",
                        "from_name": "table_elements",
                        "to_name": "image",
                        "type": "rectanglelabels",
                        "origin": "prediction",
                        "original_width": page.width_px,
                        "original_height": page.height_px,
                        "image_rotation": 0,
                        "value": _pct_box([tb[0], ry0, tb[2], max(0.005, ry1 - ry0)], lbl),
                    }
                )

        for c_idx in sorted(col_x0s):
            cx0 = min(col_x0s[c_idx])
            cx1 = max(col_x1s[c_idx])
            results.append(
                {
                    "id": f"col_{page.page_number}_{blk.block_index}_{c_idx}",
                    "from_name": "table_elements",
                    "to_name": "image",
                    "type": "rectanglelabels",
                    "origin": "prediction",
                    "original_width": page.width_px,
                    "original_height": page.height_px,
                    "image_rotation": 0,
                    "value": _pct_box([cx0, tb[1], max(0.005, cx1 - cx0), tb[3]], "Table_Col"),
                }
            )

    return {
        "data": {
            "image": f"{local_files_prefix}pages/{page.image_rel_path}",
            "document_id": page.document_id,
            "page_id": page.page_id,
            "page_number": page.page_number,
            "source_pdf": page.source_pdf,
        },
        "predictions": [{"model_version": "ocria_nano_table_bands_v1", "result": results}],
    }


def _build_p3_pairwise_task(
    page: PagePrediction,
    enhanced_markdown: str,
    local_files_prefix: str,
) -> Dict[str, Any]:
    """Create a 1-click blinded A-vs-B comparison task (OCRia-nano-1 Raw vs OCRia-nano-1 Enhanced)."""
    raw_html = "<pre style='white-space:pre-wrap;font-size:12px;'>" + html.escape(page.markdown or page.text) + "</pre>"
    enh_html = "<pre style='white-space:pre-wrap;font-size:12px;'>" + html.escape(enhanced_markdown) + "</pre>"

    swap = int(hashlib.md5(page.page_id.encode("utf-8")).hexdigest(), 16) % 2 == 1
    if swap:
        cand_a, cand_b = enh_html, raw_html
        mapping = {"A": "ocria_nano_enhanced", "B": "ocria_nano_baseline"}
    else:
        cand_a, cand_b = raw_html, enh_html
        mapping = {"A": "ocria_nano_baseline", "B": "ocria_nano_enhanced"}

    return {
        "data": {
            "image": f"{local_files_prefix}pages/{page.image_rel_path}",
            "document_id": page.document_id,
            "page_id": page.page_id,
            "page_number": page.page_number,
            "source_pdf": page.source_pdf,
            "cand_a_html": cand_a,
            "cand_b_html": cand_b,
            "blind_mapping": mapping,
        }
    }


def run_auto_preannotate(root_dir: Optional[Path] = None) -> Dict[str, Any]:
    """Run OCRia-nano-1 baseline vs CLAHE-enhanced self-consistency on 12 diverse pages."""
    root = (root_dir or Path.cwd()).resolve()
    cfg = load_pipeline_config(root / "configs/pipeline.yaml")
    paths = cfg["paths"]
    prefix = str(cfg.get("label_studio", {}).get("local_files_prefix", "/data/local-files/?d="))

    pages_jsonl = (root / paths["predictions_dir"] / "pages.jsonl").resolve()
    pages_dir = (root / paths["pages_dir"]).resolve()
    out_dir = (root / paths["label_studio_dir"]).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    baseline_report_path = (root / paths["baseline_eval_dir"] / "baseline_report.json").resolve()

    all_pages = [
        PagePrediction.model_validate_json(line)
        for line in pages_jsonl.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    smart_pages = _select_smart12_pages(all_pages, baseline_report_path)

    lp_parser = LiteParse(
        ocr_backend="ocria-nano",
        output_format="markdown",
        dpi=300,
        keep_headers_footers=True,
        extract_blocks=True,
        ocr_despeckle_scans=True,
        preserve_very_small_text=True,
        quiet=True,
    )

    p1_smart: List[Dict[str, Any]] = []
    p1_focus: List[Dict[str, Any]] = []
    p2_smart: List[Dict[str, Any]] = []
    p3_smart: List[Dict[str, Any]] = []
    consensus_by_page: Dict[str, List[Dict[str, Any]]] = {}

    total_boxes_full = 0
    total_boxes_focus = 0

    with tempfile.TemporaryDirectory() as tmp_str:
        tmp_dir = Path(tmp_str)
        for pg in smart_pages:
            img_path = pages_dir / pg.image_rel_path
            enh_items, enh_md = _run_ocria_enhanced_on_page(lp_parser, img_path, tmp_dir, pg.page_id)
            full_t, focus_t, consensus = _build_auto_p1_tasks(pg, enh_items, prefix)
            p1_smart.append(full_t)
            p1_focus.append(focus_t)
            consensus_by_page[pg.page_id] = consensus

            total_boxes_full += sum(1 for r in full_t["predictions"][0]["result"] if r["type"] == "rectanglelabels")
            total_boxes_focus += sum(1 for r in focus_t["predictions"][0]["result"] if r["type"] == "rectanglelabels")

            p2_t = _build_auto_p2_table_task(pg, prefix)
            if p2_t is not None:
                p2_smart.append(p2_t)
            p3_smart.append(_build_p3_pairwise_task(pg, enh_md, prefix))

    (out_dir / "ls_p1_smart12.json").write_text(json.dumps(p1_smart, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "ls_p1_focus12.json").write_text(json.dumps(p1_focus, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "ls_p2_smart12.json").write_text(json.dumps(p2_smart, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "ls_p3_smart12.json").write_text(json.dumps(p3_smart, indent=2, ensure_ascii=False), encoding="utf-8")
    (out_dir / "auto_consensus_p1.json").write_text(json.dumps(consensus_by_page, indent=2), encoding="utf-8")

    reduction_pct = round(100.0 * (1.0 - total_boxes_focus / max(1, total_boxes_full)), 1)
    return {
        "engine": "ocria-nano-only (baseline vs CLAHE-enhanced)",
        "smart_pages": len(smart_pages),
        "p2_table_pages": len(p2_smart),
        "p3_pairwise_pages": len(p3_smart),
        "total_boxes_full": total_boxes_full,
        "total_boxes_focus": total_boxes_focus,
        "box_reduction_pct": reduction_pct,
        "files": {
            "p1_smart12": str(out_dir / "ls_p1_smart12.json"),
            "p1_focus12": str(out_dir / "ls_p1_focus12.json"),
            "p2_smart12": str(out_dir / "ls_p2_smart12.json"),
            "p3_smart12": str(out_dir / "ls_p3_smart12.json"),
            "auto_consensus": str(out_dir / "auto_consensus_p1.json"),
        },
    }
