"""Compile Label Studio LS-P1 and LS-P2 JSON exports into versioned OCR & Table ground-truth datasets."""

from __future__ import annotations

import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from pipeline.schemas import (
    CorrectedRegion,
    OCRGroundTruthPage,
    PagePrediction,
    SolvedTable,
    SolvedTableCell,
    TableGroundTruthPage,
)

_NON_TEXT_LABELS = {"Signature", "Stamp_Seal"}
_CRITICAL_LABELS = {"Numeric_Total", "Key_Field"}
_NUMERIC_CONTENT_RE = re.compile(r"\d")


def _bbox_pct_to_norm(val: Dict[str, Any]) -> List[float]:
    return [
        round(max(0.0, min(1.0, float(val["x"]) / 100.0)), 6),
        round(max(0.0, min(1.0, float(val["y"]) / 100.0)), 6),
        round(max(0.0, min(1.0, float(val["width"]) / 100.0)), 6),
        round(max(0.0, min(1.0, float(val["height"]) / 100.0)), 6),
    ]


def _bbox_iou(a: List[float], b: List[float]) -> float:
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if inter <= 0.0:
        return 0.0
    union = max(1e-9, a[2] * a[3] + b[2] * b[3] - inter)
    return inter / union


def _overlap_fraction_1d(a0: float, a1: float, b0: float, b1: float) -> float:
    inter = max(0.0, min(a1, b1) - max(a0, b0))
    denom = max(1e-9, a1 - a0)
    return inter / denom


def _select_annotation(task: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Choose the latest non-cancelled annotation (preferring ground_truth=True if present)."""
    anns = [a for a in task.get("annotations", []) if not a.get("was_cancelled", False)]
    if not anns:
        return None
    gt_anns = [a for a in anns if a.get("ground_truth")]
    pool = gt_anns or anns
    return sorted(pool, key=lambda a: a.get("updated_at") or a.get("created_at") or "")[-1]


def _load_pages_by_id(pages_jsonl: Path) -> Dict[str, PagePrediction]:
    pages: Dict[str, PagePrediction] = {}
    if not pages_jsonl.exists():
        return pages
    for line in pages_jsonl.read_text(encoding="utf-8").splitlines():
        if line.strip():
            pg = PagePrediction.model_validate_json(line)
            pages[pg.page_id] = pg
    return pages


def compile_p1_export(
    p1_export_path: Path,
    pages_jsonl_path: Path,
    out_dir: Path,
    dataset_version: str,
    consensus_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Compile LS-P1 exported JSON into ocr_gt.jsonl + tabular parquet summary."""
    raw_tasks = json.loads(p1_export_path.read_text(encoding="utf-8"))
    pages_by_id = _load_pages_by_id(pages_jsonl_path)
    consensus_by_page: Dict[str, List[Dict[str, Any]]] = {}
    if consensus_path and consensus_path.exists():
        consensus_by_page = json.loads(consensus_path.read_text(encoding="utf-8"))

    out_dir.mkdir(parents=True, exist_ok=True)
    gt_pages: List[OCRGroundTruthPage] = []
    summary_rows: List[Dict[str, Any]] = []
    error_counter: Counter[str] = Counter()
    severity_counter: Counter[str] = Counter()

    for task in raw_tasks:
        ann = _select_annotation(task)
        if ann is None:
            continue
        data = task.get("data", {})
        page_id = str(data.get("page_id", ""))
        base_page = pages_by_id.get(page_id)

        regions_by_id: Dict[str, Dict[str, Any]] = {}
        error_categories: List[str] = []
        error_severity = "S0_Cosmetic"
        notes: Optional[str] = None

        for res in ann.get("result", []):
            rtype = res.get("type")
            from_name = res.get("from_name")
            val = res.get("value", {})
            rid = str(res.get("id", ""))

            if rtype == "rectanglelabels" and from_name == "region_type":
                entry = regions_by_id.setdefault(rid, {})
                entry["label"] = (val.get("rectanglelabels") or ["Text_Line"])[0]
                entry["bbox_norm"] = _bbox_pct_to_norm(val)
            elif rtype == "textarea" and from_name == "transcription":
                entry = regions_by_id.setdefault(rid, {})
                txt_list = val.get("text") or []
                entry["corrected_text"] = txt_list[0] if txt_list else ""
                if "bbox_norm" not in entry and "x" in val:
                    entry["bbox_norm"] = _bbox_pct_to_norm(val)
            elif rtype == "choices" and from_name == "error_categories":
                error_categories = list(val.get("choices") or [])
            elif rtype == "choices" and from_name == "error_severity":
                choices = val.get("choices") or []
                if choices:
                    error_severity = str(choices[0])
            elif rtype == "textarea" and from_name == "annotation_notes":
                txt_list = val.get("text") or []
                notes = txt_list[0] if txt_list else None

        # Index baseline items by predicted region id and bbox
        pred_text_by_rid: Dict[str, str] = {}
        for pred in task.get("predictions", []):
            for pres in pred.get("result", []):
                if pres.get("from_name") == "transcription":
                    ptxt = (pres.get("value", {}).get("text") or [""])[0]
                    pred_text_by_rid[str(pres.get("id", ""))] = ptxt

        base_items = base_page.text_items if base_page else []
        compiled_regions: List[CorrectedRegion] = []
        counts: Counter[str] = Counter()

        for rid, reg in regions_by_id.items():
            label = reg.get("label", "Text_Line")
            bbox_norm = reg.get("bbox_norm", [0.0, 0.0, 0.0, 0.0])
            corr_text = reg.get("corrected_text")

            pred_text = pred_text_by_rid.get(rid)
            if pred_text is None and base_items:
                best_iou, best_txt = 0.0, None
                for bi in base_items:
                    b_norm = [bi.bbox.x_norm, bi.bbox.y_norm, bi.bbox.width_norm, bi.bbox.height_norm]
                    iou = _bbox_iou(bbox_norm, b_norm)
                    if iou > best_iou:
                        best_iou, best_txt = iou, bi.text
                if best_iou >= 0.4:
                    pred_text = best_txt

            if label == "Missing_Text":
                action = "added"
            elif label == "Hallucinated_Text":
                action = "hallucinated"
            elif label in _NON_TEXT_LABELS:
                action = "non_text"
            elif pred_text is None:
                action = "added"
            elif (corr_text or "").strip() == pred_text.strip():
                action = "unchanged"
            else:
                action = "modified"

            is_crit = label in _CRITICAL_LABELS or (
                bool({"ERR_NUMERIC", "ERR_TOTAL"} & set(error_categories))
                and bool(_NUMERIC_CONTENT_RE.search((corr_text or pred_text or "")))
                and action in ("modified", "added")
            )

            counts[action] += 1
            if is_crit:
                counts["critical_numeric"] += 1

            compiled_regions.append(
                CorrectedRegion(
                    region_id=rid,
                    label=label,
                    bbox_norm=bbox_norm,
                    predicted_text=pred_text,
                    corrected_text=corr_text,
                    action=action,
                    is_critical_numeric=is_crit,
                )
            )

        # Merge back any auto-verified consensus boxes skipped in focus12 mode
        existing_ids = {r.region_id for r in compiled_regions}
        for creg in consensus_by_page.get(page_id, []):
            if creg["region_id"] not in existing_ids:
                compiled_regions.append(CorrectedRegion(**creg))
                counts["unchanged"] += 1

        for ec in error_categories:
            error_counter[ec] += 1
        severity_counter[error_severity] += 1

        gt_page = OCRGroundTruthPage(
            dataset_version=dataset_version,
            document_id=str(data.get("document_id", base_page.document_id if base_page else "")),
            page_id=page_id,
            page_number=int(data.get("page_number", base_page.page_number if base_page else 0)),
            source_pdf=str(data.get("source_pdf", base_page.source_pdf if base_page else "")),
            image_rel_path=str(base_page.image_rel_path if base_page else ""),
            width_px=int(task.get("meta", {}).get("width_px") or (base_page.width_px if base_page else 0)),
            height_px=int(task.get("meta", {}).get("height_px") or (base_page.height_px if base_page else 0)),
            baseline_model=str(data.get("baseline_model", "ocria-nano@1.0.0")),
            annotator_id=str(ann.get("completed_by", "unknown")),
            annotation_id=int(ann.get("id", 0)),
            lead_time_sec=ann.get("lead_time"),
            error_categories=error_categories,
            error_severity=error_severity,
            annotation_notes=notes,
            regions=compiled_regions,
            summary_counts=dict(counts),
        )
        gt_pages.append(gt_page)

        summary_rows.append(
            {
                "dataset_version": dataset_version,
                "page_id": gt_page.page_id,
                "document_id": gt_page.document_id,
                "page_number": gt_page.page_number,
                "error_severity": gt_page.error_severity,
                "error_categories": ",".join(gt_page.error_categories),
                "regions_total": len(compiled_regions),
                "modified": counts["modified"],
                "added": counts["added"],
                "hallucinated": counts["hallucinated"],
                "critical_numeric": counts["critical_numeric"],
                "annotator_id": gt_page.annotator_id,
            }
        )

    gt_path = out_dir / "ocr_gt.jsonl"
    gt_path.write_text("\n".join(p.model_dump_json() for p in gt_pages) + ("\n" if gt_pages else ""), encoding="utf-8")

    pq_path = out_dir / "ocr_feedback_summary.parquet"
    pd.DataFrame(summary_rows).to_parquet(pq_path, index=False)

    return {
        "pages_compiled": len(gt_pages),
        "ocr_gt_path": str(gt_path),
        "summary_parquet_path": str(pq_path),
        "severity_counts": dict(severity_counter),
        "error_category_counts": dict(error_counter),
    }


def _parse_span_text(span_str: Optional[str]) -> Optional[Tuple[int, int]]:
    if not span_str:
        return None
    m = re.match(r"^\s*(\d+)\s*,\s*(\d+)\s*$", span_str)
    if not m:
        return None
    return max(1, int(m.group(1))), max(1, int(m.group(2)))


def solve_table_grid(
    table_id: str,
    table_bbox: List[float],
    header_rows: List[List[float]],
    data_rows: List[List[float]],
    cols: List[List[float]],
    merged_cells: List[Dict[str, Any]],
    cell_overrides: List[Dict[str, Any]],
    ocr_tokens: List[Dict[str, Any]],
) -> SolvedTable:
    """Solve logical row/col/rowspan/colspan grid and HTML from LS-P2 annotations + OCR tokens."""
    tagged_rows = [("header", b) for b in header_rows] + [("data", b) for b in data_rows]
    tagged_rows.sort(key=lambda item: item[1][1] + item[1][3] * 0.5)
    sorted_cols = sorted(cols, key=lambda b: b[0] + b[2] * 0.5)

    n_rows = len(tagged_rows)
    n_cols = len(sorted_cols)
    header_indices = [i for i, (kind, _) in enumerate(tagged_rows) if kind == "header"]

    if n_rows == 0 or n_cols == 0:
        return SolvedTable(
            table_id=table_id,
            bbox_norm=table_bbox,
            num_rows=n_rows,
            num_cols=n_cols,
            header_row_indices=header_indices,
            cells=[],
            html="<table></table>",
        )

    # Pre-assign OCR tokens into (r, c) cells by bbox center containment
    cell_tokens: Dict[Tuple[int, int], List[Dict[str, Any]]] = {(r, c): [] for r in range(n_rows) for c in range(n_cols)}
    for tok in ocr_tokens:
        tb = tok["bbox_norm"]
        cx = tb[0] + tb[2] * 0.5
        cy = tb[1] + tb[3] * 0.5
        r_match = next(
            (r for r, (_, rb) in enumerate(tagged_rows) if rb[1] <= cy <= rb[1] + rb[3]),
            None,
        )
        c_match = next(
            (c for c, cb in enumerate(sorted_cols) if cb[0] <= cx <= cb[0] + cb[2]),
            None,
        )
        if r_match is not None and c_match is not None:
            cell_tokens[(r_match, c_match)].append(tok)

    # Map Merged_Cell annotations to grid coordinates and covered shadow cells
    occupied: Dict[Tuple[int, int], bool] = {}
    anchor_cells: Dict[Tuple[int, int], SolvedTableCell] = {}

    for mc in merged_cells:
        mb = mc["bbox_norm"]
        ov_rows = [
            r for r, (_, rb) in enumerate(tagged_rows)
            if _overlap_fraction_1d(rb[1], rb[1] + rb[3], mb[1], mb[1] + mb[3]) >= 0.35
        ]
        ov_cols = [
            c for c, cb in enumerate(sorted_cols)
            if _overlap_fraction_1d(cb[0], cb[0] + cb[2], mb[0], mb[0] + mb[2]) >= 0.35
        ]
        if not ov_rows or not ov_cols:
            continue
        r0, c0 = min(ov_rows), min(ov_cols)
        parsed = _parse_span_text(mc.get("cell_span"))
        rs = parsed[0] if parsed else len(ov_rows)
        cs = parsed[1] if parsed else len(ov_cols)
        rs = min(rs, n_rows - r0)
        cs = min(cs, n_cols - c0)

        text = (mc.get("cell_text") or "").strip()
        if not text:
            gathered = []
            for rr in range(r0, r0 + rs):
                for cc in range(c0, c0 + cs):
                    gathered.extend(cell_tokens[(rr, cc)])
            gathered.sort(key=lambda t: (round(t["bbox_norm"][1], 3), t["bbox_norm"][0]))
            text = " ".join(t["text"].strip() for t in gathered if t["text"].strip())

        is_hdr = r0 in header_indices
        anchor_cells[(r0, c0)] = SolvedTableCell(
            row=r0,
            col=c0,
            rowspan=rs,
            colspan=cs,
            is_header=is_hdr,
            text=text,
            bbox_norm=mb,
            source="merged_cell",
        )
        for rr in range(r0, r0 + rs):
            for cc in range(c0, c0 + cs):
                occupied[(rr, cc)] = True

    # Map Cell_Override annotations
    override_map: Dict[Tuple[int, int], Dict[str, Any]] = {}
    for ov in cell_overrides:
        ob = ov["bbox_norm"]
        cx, cy = ob[0] + ob[2] * 0.5, ob[1] + ob[3] * 0.5
        r_match = next((r for r, (_, rb) in enumerate(tagged_rows) if rb[1] <= cy <= rb[1] + rb[3]), None)
        c_match = next((c for c, cb in enumerate(sorted_cols) if cb[0] <= cx <= cb[0] + cb[2]), None)
        if r_match is not None and c_match is not None:
            override_map[(r_match, c_match)] = ov

    # Fill remaining non-covered cells
    solved_cells: List[SolvedTableCell] = []
    for r in range(n_rows):
        for c in range(n_cols):
            if (r, c) in anchor_cells:
                solved_cells.append(anchor_cells[(r, c)])
                continue
            if occupied.get((r, c), False):
                continue
            rb, cb = tagged_rows[r][1], sorted_cols[c]
            cell_bbox = [cb[0], rb[1], cb[2], rb[3]]
            is_hdr = r in header_indices
            if (r, c) in override_map:
                ov = override_map[(r, c)]
                solved_cells.append(
                    SolvedTableCell(
                        row=r,
                        col=c,
                        is_header=is_hdr,
                        text=(ov.get("cell_text") or "").strip(),
                        bbox_norm=ov["bbox_norm"],
                        source="cell_override",
                    )
                )
            else:
                toks = sorted(cell_tokens[(r, c)], key=lambda t: (round(t["bbox_norm"][1], 3), t["bbox_norm"][0]))
                txt = " ".join(t["text"].strip() for t in toks if t["text"].strip())
                solved_cells.append(
                    SolvedTableCell(
                        row=r,
                        col=c,
                        is_header=is_hdr,
                        text=txt,
                        bbox_norm=cell_bbox,
                        source="ocr_snap" if txt else "empty",
                    )
                )

    # Render HTML
    cells_by_row: Dict[int, List[SolvedTableCell]] = {r: [] for r in range(n_rows)}
    for sc in solved_cells:
        cells_by_row[sc.row].append(sc)

    def _render_rows(row_ids: List[int], tag: str) -> str:
        parts: List[str] = []
        for r in row_ids:
            tds: List[str] = []
            for sc in sorted(cells_by_row[r], key=lambda x: x.col):
                attrs = ""
                if sc.rowspan > 1:
                    attrs += f' rowspan="{sc.rowspan}"'
                if sc.colspan > 1:
                    attrs += f' colspan="{sc.colspan}"'
                tds.append(f"<{tag}{attrs}>{html.escape(sc.text)}</{tag}>")
            parts.append(f"<tr>{''.join(tds)}</tr>")
        return "".join(parts)

    hdr_set = set(header_indices)
    body_indices = [r for r in range(n_rows) if r not in hdr_set]
    thead = f"<thead>{_render_rows(header_indices, 'th')}</thead>" if header_indices else ""
    tbody = f"<tbody>{_render_rows(body_indices, 'td')}</tbody>" if body_indices else ""
    table_html = f"<table>{thead}{tbody}</table>"

    return SolvedTable(
        table_id=table_id,
        bbox_norm=table_bbox,
        num_rows=n_rows,
        num_cols=n_cols,
        header_row_indices=header_indices,
        cells=solved_cells,
        html=table_html,
    )


def compile_p2_export(
    p2_export_path: Path,
    pages_jsonl_path: Path,
    out_dir: Path,
    dataset_version: str,
    ocr_gt_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Compile LS-P2 table-structure exported JSON into canonical table_gt.jsonl."""
    raw_tasks = json.loads(p2_export_path.read_text(encoding="utf-8"))
    pages_by_id = _load_pages_by_id(pages_jsonl_path)

    gt_ocr_by_page: Dict[str, List[Dict[str, Any]]] = {}
    if ocr_gt_path and ocr_gt_path.exists():
        for line in ocr_gt_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            pg_gt = OCRGroundTruthPage.model_validate_json(line)
            gt_ocr_by_page[pg_gt.page_id] = [
                {"text": r.corrected_text or "", "bbox_norm": r.bbox_norm}
                for r in pg_gt.regions
                if r.action not in ("hallucinated", "non_text") and (r.corrected_text or "").strip()
            ]

    out_dir.mkdir(parents=True, exist_ok=True)
    gt_tables_pages: List[TableGroundTruthPage] = []
    total_tables = 0

    for task in raw_tasks:
        ann = _select_annotation(task)
        if ann is None:
            continue
        data = task.get("data", {})
        page_id = str(data.get("page_id", ""))
        base_page = pages_by_id.get(page_id)

        if page_id in gt_ocr_by_page:
            ocr_tokens = gt_ocr_by_page[page_id]
        elif base_page:
            ocr_tokens = [
                {
                    "text": ti.text,
                    "bbox_norm": [ti.bbox.x_norm, ti.bbox.y_norm, ti.bbox.width_norm, ti.bbox.height_norm],
                }
                for ti in base_page.text_items
                if ti.text.strip()
            ]
        else:
            ocr_tokens = []

        regions_by_id: Dict[str, Dict[str, Any]] = {}
        for res in ann.get("result", []):
            rid = str(res.get("id", ""))
            rtype = res.get("type")
            from_name = res.get("from_name")
            val = res.get("value", {})
            entry = regions_by_id.setdefault(rid, {})
            if rtype == "rectanglelabels" and from_name == "table_elements":
                entry["label"] = (val.get("rectanglelabels") or ["Table"])[0]
                entry["bbox_norm"] = _bbox_pct_to_norm(val)
            elif rtype == "textarea" and from_name == "cell_text":
                txt_list = val.get("text") or []
                entry["cell_text"] = txt_list[0] if txt_list else ""
            elif rtype == "textarea" and from_name == "cell_span":
                txt_list = val.get("text") or []
                entry["cell_span"] = txt_list[0] if txt_list else ""

        tables_boxes = [r["bbox_norm"] for r in regions_by_id.values() if r.get("label") == "Table"]
        if not tables_boxes:
            tables_boxes = [[0.0, 0.0, 1.0, 1.0]]

        solved_tables: List[SolvedTable] = []
        for idx, tb in enumerate(tables_boxes):
            def _in_table(reg_box: List[float]) -> bool:
                cx, cy = reg_box[0] + reg_box[2] * 0.5, reg_box[1] + reg_box[3] * 0.5
                return tb[0] <= cx <= tb[0] + tb[2] and tb[1] <= cy <= tb[1] + tb[3]

            hdr_rows = [
                r["bbox_norm"]
                for r in regions_by_id.values()
                if r.get("label") == "Table_Header_Row" and _in_table(r["bbox_norm"])
            ]
            data_rows = [
                r["bbox_norm"]
                for r in regions_by_id.values()
                if r.get("label") == "Table_Row" and _in_table(r["bbox_norm"])
            ]
            cols = [
                r["bbox_norm"]
                for r in regions_by_id.values()
                if r.get("label") == "Table_Col" and _in_table(r["bbox_norm"])
            ]
            merged = [
                r for r in regions_by_id.values()
                if r.get("label") == "Merged_Cell" and _in_table(r["bbox_norm"])
            ]
            overrides = [
                r for r in regions_by_id.values()
                if r.get("label") == "Cell_Override" and _in_table(r["bbox_norm"])
            ]
            solved = solve_table_grid(
                table_id=f"{page_id}_tbl_{idx + 1:02d}",
                table_bbox=tb,
                header_rows=hdr_rows,
                data_rows=data_rows,
                cols=cols,
                merged_cells=merged,
                cell_overrides=overrides,
                ocr_tokens=ocr_tokens,
            )
            solved_tables.append(solved)
            total_tables += 1

        gt_tables_pages.append(
            TableGroundTruthPage(
                dataset_version=dataset_version,
                document_id=str(data.get("document_id", base_page.document_id if base_page else "")),
                page_id=page_id,
                page_number=int(data.get("page_number", base_page.page_number if base_page else 0)),
                source_pdf=str(data.get("source_pdf", base_page.source_pdf if base_page else "")),
                annotator_id=str(ann.get("completed_by", "unknown")),
                annotation_id=int(ann.get("id", 0)),
                tables=solved_tables,
            )
        )

    tbl_path = out_dir / "table_gt.jsonl"
    tbl_path.write_text(
        "\n".join(p.model_dump_json() for p in gt_tables_pages) + ("\n" if gt_tables_pages else ""),
        encoding="utf-8",
    )
    return {
        "pages_compiled": len(gt_tables_pages),
        "tables_compiled": total_tables,
        "table_gt_path": str(tbl_path),
    }
