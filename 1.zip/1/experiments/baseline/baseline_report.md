# Phase 1 Baseline Evaluation Report (`OCRia-nano-1` + Fixed LiteParse Config)

- **Documents:** 6 | **Total Pages:** 72
- **Avg Latency:** 749.5 ms/page
- **Headers Recovered:** 28 | **Footers Recovered:** 129
- **Table Blocks Detected:** 93
- **Low-Confidence Lines (<0.70):** 75

## Per-Document Baseline Summary

| Document | Pages | ms/page | Text Items | Mean Conf | Conf <0.70 | Footers | Tables | Legacy MD Chars | New MD Chars |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 3._WT_HT_214-54_NOS..pdf | 1 | 1748.5 | 145 | 0.982 | 0 | 0 | 1 | 2366 | 2366 |
| Brake_Ring_small.pdf | 2 | 1158.5 | 345 | 0.983 | 1 | 2 | 9 | 9249 | 9242 |
| Dimensional_Inspection_Report_1_-_13.pdf | 13 | 722.0 | 3052 | 0.980 | 7 | 4 | 15 | 65316 | 65232 |
| Handle-Cap_for_Launcher_Tube.pdf | 2 | 985.0 | 337 | 0.969 | 2 | 0 | 4 | 9708 | 9701 |
| Lot_17_Part_1_Page_01_to_Page_50_0001.pdf | 50 | 713.2 | 16523 | 0.977 | 54 | 114 | 60 | 314724 | 314381 |
| Page_111_to_114_X-Ray_Test_Report_for_Throat_Insert.pdf | 4 | 721.1 | 415 | 0.974 | 11 | 9 | 4 | 18296 | 18275 |

## `Problems.md` Diagnostic Checks (`Page_111_to_114_X-Ray_Test_Report_for_Throat_Insert.pdf`)
- **Problem A (Signatures/Dates):** `Exposed By Rakesh`=True, `14/05/26`=True, `15/5/26`=False, `Pankaj`=False
- **Problem B (Table):** Part codes `E-02..E-18` found=17/17, missing=[], rows with phantom trailing `<td></td>`=19/26
- **Footer Recovery (`keep_headers_footers=True`):** 9 footer blocks detected (legacy had 0).

## Top 15 Priority Pages for  Human Annotation

| Rank | Page ID | Mean Conf | Conf <0.70 | Conf <0.50 | Tables | Empty Cell Ratio | Priority Score |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | `page_111_to_114_x_ray_test_report_for_throat_insert_p0004` | 0.938 | 6 | 3 | 1 | 0.40 | 16.538 |
| 2 | `page_111_to_114_x_ray_test_report_for_throat_insert_p0001` | 0.971 | 3 | 2 | 1 | 0.41 | 12.119 |
| 3 | `lot_17_part_1_page_01_to_page_50_0001_p0008` | 0.975 | 3 | 3 | 1 | 0.27 | 11.292 |
| 4 | `lot_17_part_1_page_01_to_page_50_0001_p0018` | 0.971 | 3 | 3 | 1 | 0.25 | 11.239 |
| 5 | `lot_17_part_1_page_01_to_page_50_0001_p0047` | 0.975 | 2 | 1 | 3 | 0.50 | 11.237 |
| 6 | `dimensional_inspection_report_1_13_p0010` | 0.969 | 3 | 1 | 1 | 0.44 | 11.219 |
| 7 | `dimensional_inspection_report_1_13_p0011` | 0.972 | 1 | 1 | 1 | 0.46 | 10.369 |
| 8 | `lot_17_part_1_page_01_to_page_50_0001_p0014` | 0.977 | 3 | 2 | 2 | 0.28 | 9.809 |
| 9 | `lot_17_part_1_page_01_to_page_50_0001_p0029` | 0.971 | 4 | 3 | 1 | 0.11 | 9.532 |
| 10 | `lot_17_part_1_page_01_to_page_50_0001_p0030` | 0.969 | 2 | 2 | 1 | 0.23 | 8.948 |
| 11 | `lot_17_part_1_page_01_to_page_50_0001_p0050` | 0.977 | 1 | 1 | 1 | 0.38 | 8.811 |
| 12 | `handle_cap_for_launcher_tube_p0001` | 0.966 | 1 | 0 | 2 | 0.44 | 8.747 |
| 13 | `lot_17_part_1_page_01_to_page_50_0001_p0010` | 0.977 | 2 | 2 | 2 | 0.24 | 8.672 |
| 14 | `dimensional_inspection_report_1_13_p0009` | 0.973 | 0 | 0 | 1 | 0.48 | 8.575 |
| 15 | `page_111_to_114_x_ray_test_report_for_throat_insert_p0002` | 0.985 | 1 | 1 | 1 | 0.38 | 8.506 |
