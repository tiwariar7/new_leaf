# Problems Identified

## A.

**Input Image:** `D:\Arman\1\Problems\1.png`

**OCR Output (Markdown):**

```text
Exposed By: Rakesh Shamkule

Inspected By: Approved By

Sign: Signː<

Rateh Brelule Panb(sh

Name: Name:

Date: 14/05/26 155/26

Date:
```

**Problem Type:**
- Incorrect text recognition
- Missing/garbled words
- Incorrect reading order
- Misinterpretation of signature fields
- Date and number recognition errors
- Missing text/content

## B.

**Input Image:** `D:\Arman\1\Problems\2.png`

**OCR Output (Markdown):**

```text
<td>Sr. No.</td>
<td>Date</td>
<td>Details</td>
<td>Observation</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-02(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT</td>
<td rowspan="2">Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>INSERT/ E-03(086)</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td rowspan="2">PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-04(086) PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-05(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td>5</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-06(086)</td>
<td>Free from voids, cracks, and flaws. Density variation observed at 0 &amp; 90 degree.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT</td>
<td rowspan="2">Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>INSERT/ E-07(086)</td>
<td></td>
</tr>
<tr>
<td>7</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-08(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td rowspan="3">14/05/2026</td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT</td>
<td>Free from voids, cracks, discontinuities, flaws</td>
<td></td>
</tr>
<tr>
<td></td>
<td>INSERT/ E-09(086)</td>
<td>and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-10(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT</td>
<td rowspan="2">Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td>INSERT/ E-11(086)</td>
<td></td>
</tr>
<tr>
<td rowspan="2">11 12</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-12(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-13(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td>13</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-14(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td>14</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-15(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td>15</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-16(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
<tr>
<td rowspan="2">16</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT</td>
<td>Free from voids, cracks, and flaws.</td>
<td></td>
</tr>
<tr>
<td></td>
<td>INSERT/ E-17(086)</td>
<td>Density variation observed at 0 &amp; 90 degree.</td>
<td></td>
</tr>
<tr>
<td>17</td>
<td></td>
<td>PINAKA MK-1 ENHANCED NOZZLE THROAT INSERT/ E-18(086)</td>
<td>Free from voids, cracks, discontinuities, flaws and density variation.</td>
<td></td>
</tr>
</table>

```

## B. Footer Not Extracted for any page


