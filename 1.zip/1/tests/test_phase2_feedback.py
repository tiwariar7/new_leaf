"""End-to-end verification tests for Phase 2 feedback compilation, table grid solver, and IAA QC."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline.feedback_compiler import compile_p1_export, compile_p2_export, solve_table_grid
from pipeline.iaa_qc import run_qc_checks


class TestPhase2Feedback(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.tmp_dir = Path(self.tmp.name)
        self.pages_jsonl = ROOT / "data/predictions/baseline_ocria_nano_v1/pages.jsonl"

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_solve_table_grid_with_merged_cell_and_override(self) -> None:
        # Simulate Problems/2.png 4-column table with 1 header row + 3 data rows and a vertically merged Date cell
        header_rows = [[0.05, 0.10, 0.90, 0.05]]
        data_rows = [
            [0.05, 0.15, 0.90, 0.05],
            [0.05, 0.20, 0.90, 0.05],
            [0.05, 0.25, 0.90, 0.05],
        ]
        cols = [
            [0.05, 0.10, 0.08, 0.20],  # Sr. No.
            [0.13, 0.10, 0.15, 0.20],  # Date
            [0.28, 0.10, 0.35, 0.20],  # Details
            [0.63, 0.10, 0.32, 0.20],  # Observation
        ]
        merged = [
            {"bbox_norm": [0.13, 0.15, 0.15, 0.15], "cell_text": "14/05/2026", "cell_span": "3,1"}
        ]
        overrides = [
            {"bbox_norm": [0.05, 0.15, 0.08, 0.05], "cell_text": "1"}
        ]
        ocr_tokens = [
            {"text": "Sr. No.", "bbox_norm": [0.06, 0.11, 0.05, 0.02]},
            {"text": "Date", "bbox_norm": [0.15, 0.11, 0.05, 0.02]},
            {"text": "Details", "bbox_norm": [0.32, 0.11, 0.08, 0.02]},
            {"text": "Observation", "bbox_norm": [0.68, 0.11, 0.12, 0.02]},
            {"text": "PINAKA MK-1", "bbox_norm": [0.30, 0.16, 0.20, 0.02]},
            {"text": "E-02(086)", "bbox_norm": [0.30, 0.18, 0.10, 0.015]},
            {"text": "2", "bbox_norm": [0.07, 0.21, 0.02, 0.02]},
            {"text": "3", "bbox_norm": [0.07, 0.26, 0.02, 0.02]},
        ]
        solved = solve_table_grid(
            table_id="tbl_test",
            table_bbox=[0.05, 0.10, 0.90, 0.20],
            header_rows=header_rows,
            data_rows=data_rows,
            cols=cols,
            merged_cells=merged,
            cell_overrides=overrides,
            ocr_tokens=ocr_tokens,
        )
        self.assertEqual(solved.num_rows, 4)
        self.assertEqual(solved.num_cols, 4)
        self.assertIn('<td rowspan="3">14/05/2026</td>', solved.html)
        self.assertIn("PINAKA MK-1 E-02(086)", solved.html)
        self.assertIn("<td>1</td>", solved.html)

    def test_compile_p1_p2_and_iaa_qc(self) -> None:
        page_id = "page_111_to_114_x_ray_test_report_for_throat_insert_p0001"
        p1_export = self.tmp_dir / "p1_export.json"
        p2_export = self.tmp_dir / "p2_export.json"

        # Two annotations on the same task to exercise IAA + compilation
        p1_tasks = [
            {
                "id": 1,
                "data": {
                    "page_id": page_id,
                    "document_id": "page_111_to_114_x_ray_test_report_for_throat_insert",
                    "page_number": 1,
                    "source_pdf": "Page_111_to_114_X-Ray_Test_Report_for_Throat_Insert.pdf",
                },
                "meta": {"width_px": 2550, "height_px": 3300},
                "predictions": [
                    {
                        "result": [
                            {"id": "ti_1_0", "from_name": "transcription", "type": "textarea", "value": {"text": ["155/26"]}},
                        ]
                    }
                ],
                "annotations": [
                    {
                        "id": 101,
                        "completed_by": 1,
                        "updated_at": "2026-11-27T10:00:00Z",
                        "result": [
                            {"id": "ti_1_0", "from_name": "region_type", "type": "rectanglelabels", "value": {"x": 55, "y": 88, "width": 8, "height": 2, "rectanglelabels": ["Numeric_Total"]}},
                            {"id": "ti_1_0", "from_name": "transcription", "type": "textarea", "value": {"x": 55, "y": 88, "width": 8, "height": 2, "text": ["15/5/26"]}},
                            {"id": "miss_1", "from_name": "region_type", "type": "rectanglelabels", "value": {"x": 5, "y": 95, "width": 30, "height": 2, "rectanglelabels": ["Missing_Text"]}},
                            {"id": "miss_1", "from_name": "transcription", "type": "textarea", "value": {"x": 5, "y": 95, "width": 30, "height": 2, "text": ["Page 1 of 4"]}},
                            {"id": "err_cat", "from_name": "error_categories", "type": "choices", "value": {"choices": ["ERR_NUMERIC", "ERR_MISSING"]}},
                            {"id": "err_sev", "from_name": "error_severity", "type": "choices", "value": {"choices": ["S3_Critical"]}},
                        ],
                    },
                    {
                        "id": 102,
                        "completed_by": 2,
                        "updated_at": "2026-11-27T11:00:00Z",
                        "result": [
                            {"id": "ti_1_0", "from_name": "region_type", "type": "rectanglelabels", "value": {"x": 55, "y": 88, "width": 8, "height": 2, "rectanglelabels": ["Numeric_Total"]}},
                            {"id": "ti_1_0", "from_name": "transcription", "type": "textarea", "value": {"x": 55, "y": 88, "width": 8, "height": 2, "text": ["15/5/26"]}},
                            {"id": "err_cat", "from_name": "error_categories", "type": "choices", "value": {"choices": ["ERR_NUMERIC", "ERR_MISSING"]}},
                            {"id": "err_sev", "from_name": "error_severity", "type": "choices", "value": {"choices": ["S3_Critical"]}},
                        ],
                    },
                ],
            }
        ]
        p2_tasks = [
            {
                "id": 1,
                "data": {"page_id": page_id, "document_id": "page_111_to_114_x_ray_test_report_for_throat_insert", "page_number": 1},
                "annotations": [
                    {
                        "id": 201,
                        "completed_by": 1,
                        "result": [
                            {"id": "t1", "from_name": "table_elements", "type": "rectanglelabels", "value": {"x": 8, "y": 15, "width": 82, "height": 70, "rectanglelabels": ["Table"]}},
                            {"id": "hr1", "from_name": "table_elements", "type": "rectanglelabels", "value": {"x": 8, "y": 15, "width": 82, "height": 5, "rectanglelabels": ["Table_Header_Row"]}},
                            {"id": "dr1", "from_name": "table_elements", "type": "rectanglelabels", "value": {"x": 8, "y": 20, "width": 82, "height": 5, "rectanglelabels": ["Table_Row"]}},
                            {"id": "c1", "from_name": "table_elements", "type": "rectanglelabels", "value": {"x": 8, "y": 15, "width": 10, "height": 70, "rectanglelabels": ["Table_Col"]}},
                            {"id": "c2", "from_name": "table_elements", "type": "rectanglelabels", "value": {"x": 18, "y": 15, "width": 72, "height": 70, "rectanglelabels": ["Table_Col"]}},
                        ],
                    }
                ],
            }
        ]

        p1_export.write_text(json.dumps(p1_tasks), encoding="utf-8")
        p2_export.write_text(json.dumps(p2_tasks), encoding="utf-8")

        qc = run_qc_checks(p1_export, p2_export, out_dir=self.tmp_dir / "qc")
        self.assertEqual(qc["p1_summary"]["severity_exact_agreement"], 1.0)
        self.assertEqual(qc["p1_summary"]["mean_transcription_similarity"], 1.0)
        self.assertEqual(qc["p1_summary"]["hygiene_issue_count"], 0)
        self.assertEqual(qc["p2_summary"]["hygiene_issue_count"], 0)

        out_dir = self.tmp_dir / "export_v1"
        p1_res = compile_p1_export(p1_export, self.pages_jsonl, out_dir, "v_test")
        p2_res = compile_p2_export(p2_export, self.pages_jsonl, out_dir, "v_test", ocr_gt_path=Path(p1_res["ocr_gt_path"]))
        self.assertEqual(p1_res["pages_compiled"], 1)
        self.assertEqual(p2_res["tables_compiled"], 1)
        self.assertTrue(Path(p1_res["summary_parquet_path"]).exists())


if __name__ == "__main__":
    unittest.main()
