# Vendor PDF Annotation & Quality Guidelines

These guidelines govern **LS-P1** (`p1_ocr_correction.xml`) and **LS-P2** (`p2_table_structure.xml`). Consistent annotations are mandatory because downstream evaluation, reranking, and fine-tuning depend directly on these labels.

---

## 1. LS-P1: OCR Text, Missing Text & Critical Numerical Errors

### 1.1 General Transcription Rules
1. **Transcribe verbatim what is visible on the page** inside each bounding box—never autocorrect vendor spelling mistakes (e.g., if the scan says `SURAFCE` or `CHEAKED`, keep `SURAFCE` / `CHEAKED`).
2. **Preserve exact formatting:**
   - Leading zeros (`004`, `086`, `E-02`), decimal precision (`1570.00`, `0.20`), and slashes/hyphens (`14/05/26` vs `14-05-2026`).
   - Engineering & currency symbols: `±`, `Φ`, `°`, `₹`, `$`, `%`, `&`, `/`. Use Unicode `±`, `Φ`, `°` consistently.
   - Multi-line text inside a single region: join wrapped lines with a single space unless a hard newline is semantically required.
3. **Region Label Selection:**
   - `Text_Line`: Standard printed prose/heading line.
   - `Header` / `Footer`: Running page headers and footers (including page numbers like `Page 1 of 4`, document control codes, and vendor footer strings).
   - `Table_Region`: Outer table bounding box (for page-level indexing; detailed cell/grid editing belongs in **LS-P2**).
   - `Key_Field`: Document identifiers and metadata (`Report No.`, `S.O. No.`, `PO No.`, `Drawing No.`, `GSTIN`, `PAN`, `Part No.`, `Serial No.`).
   - `Numeric_Total`: Quantities, tolerances, dimensions, prices, taxes, subtotals, grand totals, and dates (`14/05/26`, `1570.0 ±2.0 MM`).
   - `Handwritten`: Any handwritten text, filled-in inspection names, or handwritten dates (`Rakesh Shamkule`, `15/5/26`).
   - `Signature`: Cursive/graphical signatures only. **Leave `transcription` empty** unless printed/legible initials are clearly readable.
   - `Stamp_Seal`: Rubber stamps, inspection seals, or logos. Transcribe legible text inside the stamp if readable; otherwise leave `transcription` empty.

### 1.2 Missing Text (`Missing_Text`)
- Draw a tight box around **any legible text on the page that OCRia-nano missed completely** (for example: dropped table rows `1`–`4`, unextracted page footers, or faint handwritten dates).
- Label the box `Missing_Text` and enter the exact visible text in `transcription`.
- **Also** select `ERR_MISSING` in page-level `error_categories`.

### 1.3 Hallucinated Text (`Hallucinated_Text`)
- **Do NOT delete** a pre-annotated box that has no real text behind it (e.g., punch holes, scan specks, bleed-through, or watermark artifacts misread as `oum` or `5`).
- Instead, change its region label to `Hallucinated_Text` (keep the predicted text as-is or clear it only after tagging) and select `ERR_HALLUCINATION` in `error_categories`.
- *Why:* Preserving flagged hallucinations lets our evaluation pipeline measure hallucination rate accurately.

### 1.4 Critical Numerical & Identifier Errors
Every page where **any** digit, decimal point, unit, date, part/serial code, quantity, or total is wrong or missing in the baseline prediction **must**:
1. Label the affected region `Numeric_Total` or `Key_Field` (or `Handwritten` if handwritten, and note the exact value in `transcription`).
2. Check `ERR_NUMERIC` (and `ERR_TOTAL` if it affects a financial subtotal/tax/grand total, or `ERR_FIELD_EXTRACT` if it is a document ID/date/PO).
3. Set `error_severity` to **`S3_Critical`**.

### 1.5 Page-Level Severity Scale
| Severity | Criteria |
|---|---|
| `S0_Cosmetic` | Minor spacing/markdown styling only; all text, numbers, reading order, and tables are usable. |
| `S1_Minor` | 1–2 non-critical character typos in prose/boilerplate; **zero** numeric, ID, or table-structure errors. |
| `S2_Major` | Noticeable reading-order scrambling (e.g., two side-by-side signature columns merged), missed non-critical header/footer, or split multi-line table row, with numbers intact. |
| `S3_Critical` | **Any** wrong/missing number, date, tolerance, part code, quantity, total, dropped table row, misaligned column value, or hallucinated line item. |

---

## 2. LS-P2: Complex Table Row, Column & Merged-Cell Corrections

Instead of drawing $N \times M$ individual cell boxes, annotate tables using **row bands + column bands + merged exceptions**:

1. **`Table`**: Draw one box around the entire table (including header and all data rows).
2. **`Table_Header_Row`**: Draw one horizontal band spanning the full table width for **each header row** (draw 2 bands for a 2-level nested header).
3. **`Table_Row`**: Draw one horizontal band spanning the full table width for **each logical data row**.
   - *Multi-line cells:* If a description wraps across 2 visual lines (e.g., `PINAKA MK-1 ENHANCED NOZZLE THROAT` + `INSERT/ E-03(086)`), draw **one single `Table_Row`** covering both lines—do NOT split into 2 rows!
4. **`Table_Col`**: Draw one vertical band spanning the full table height for **each true column**.
   - Do **not** draw phantom empty columns caused by punch holes or right-margin whitespace.
5. **`Merged_Cell`**: Draw an explicit box **only** where a cell spans multiple rows or columns (e.g., `14/05/2026` spanning 17 rows, or a title cell spanning 2 columns).
   - Enter `cell_span` as `rowspan,colspan` (for example: `17,1` or `1,2`).
   - Enter `cell_text` with the exact cell text.
6. **`Cell_Override`**: Draw a box over any individual cell whose pre-annotated OCR text is wrong or missing, and enter the exact corrected text in `cell_text`.

---

## 3. Quality Control & Consensus Protocol
- **Pilot First:** Annotate the 15-page priority pilot (`ls_p1_pilot15.json` and `ls_p2_pilot15.json`) before scaling to the remaining 57 pages.
- **Calibration Overlap:** 15% of tasks (`ls_p1_iaa_overlap.json`) are assigned to 2 annotators independently. Target agreement:
  - Severity exact agreement $\ge 85\%$ (Cohen's $\kappa \ge 0.75$)
  - Region transcription similarity $\ge 0.97$ ($1 - \text{CER}$)
  - Table row & column count exact agreement $\ge 95\%$
- Run `python -m pipeline.main check-qc --p1-export <path> [--p2-export <path>]` after exporting to validate schema hygiene and agreement before compiling the dataset.
